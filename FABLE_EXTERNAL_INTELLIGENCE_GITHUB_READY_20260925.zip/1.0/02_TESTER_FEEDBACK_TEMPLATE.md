# Tester Feedback Template

実験結果を返す際は、可能なら次を添えてください。

- Model name:
- Quantization:
- Runtime / version:
- GPU / VRAM:
- RAM:
- Context limit:
- `RUNS/<run-id>/analysis.md`:
- `RUNS/<run-id>/analysis.json`:

## 所感

- 素のモデルより明確に良くなった場面:
- 悪化した場面:
- 遅すぎたarm:
- 特に効いたarm:
- エラー / 再現不能:
- その他:
