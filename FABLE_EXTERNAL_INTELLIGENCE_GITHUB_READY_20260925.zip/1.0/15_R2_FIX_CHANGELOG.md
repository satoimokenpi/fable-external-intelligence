# R2 benchmark-integrity fix changelog

R2 is a benchmark-integrity repair of the tester Alpha. It does **not** claim real-model lift; it makes the forthcoming live benchmark harder to fool accidentally.

## Fixed from external review

1. **Judge/selector calls were under-counted**
   - `_call()` is now the single accounting point for every inference attempt.
   - Calls made by `_judge()` and `_select()` are included in `inference_call_attempts`, token/usage totals, elapsed time, and raw call records.
   - The self-test explicitly checks `independent N4 = 4 branches + 1 selector = 5 calls` and `fresh judge = solve + judge = 2 calls`.

2. **Policy freeze was too weak**
   - Freeze now requires the complete E0-E7 dev matrix at the frozen repetition count.
   - All required rows must use the same exact runtime config and current study-definition hash.
   - Each persisted completed trial is re-scored from its output and task definition, and its raw call-record file is cross-checked against the JSONL row.
   - Holdout re-checks the dev digest, required slot set, config/study identity, raw/result consistency, and recomputes dev winners. Editing the snapshot winner or changing policy/sampling after freeze is rejected.
   - Mock and live evidence cannot be mixed across a frozen study.

3. **E8 could overclaim transfer from one target**
   - `KEEP` for the whole frozen policy requires **at least two complete, distinct target identities**, each with complete `A0_BARE` versus frozen-winner E8 holdout data.
   - One complete target is at most `MODEL_CONDITIONED`.
   - `transfer.target_tag` no longer creates a new target identity by itself.
   - If E7 selects an `A0_*` control baseline, E8 is not allowed to manufacture a transferable external policy; status becomes `NO_EXTERNAL_POLICY_SURVIVED_DEV` and the policy is `DROP`.

4. **API failure aborted the experiment and disappeared from accounting**
   - A failed model call is persisted as a `FAILED` trial rather than terminating the experiment loop.
   - Failed call attempt, attempted output cap, estimated input, elapsed time, error type/message, and `billed_usage_unknown` are recorded.
   - Failed slots can be retried on a later invocation with a new `attempt=N`; a later completed attempt supplies quality while earlier failures remain in reliability/resource accounting.

5. **`json_subset` could pass while obligations were missing**
   - Final offline score is now `min(content_score, completion_score)`.
   - `passed=true` requires both full content correctness and all declared obligations present.
   - A response with every expected subset value correct but a missing mandatory field cannot pass.

## Generalization/evaluator hardening

- 13 objective/fixed-answer tasks now generate deterministic per-repeat variants. The same task/repeat is identical across arms, while different repeats change the concrete numbers/content. This reduces constant-answer memorization while preserving paired A/B fairness.
- Added optional blind local LLM-as-a-judge for rubric/open-ended tasks. Judge results are post-hoc and stored separately from generation resources.
- Added generic external-evaluator JSONL import for Jev-style evaluators, human labels, LangSmith, or another scorer. External scores never replace deterministic ground truth.
- Judge prompts treat candidate answers as untrusted data and hide arm identity.

## Added integrity checks beyond the reported issues

- Persisted trial score is recomputed before freeze/holdout.
- `results.jsonl` is cross-checked against the corresponding raw call-record file.
- Call counts, success/failure counts, token reports/estimates, and attempted output caps are cross-checked.
- Snapshot selected arms are recomputed from frozen dev evidence before every holdout run.
- Target identity excludes arbitrary display tags.
- Public/provider endpoints remain rejected; benchmark generation stays local-only.

## Validation of this R2 build

- Unit/mock self-tests: **19/19 PASS**
- End-to-end synthetic live-tagged integration: **1,795 completed trial records, 0 failures**
  - E0-E7 dev
  - freeze
  - E1-E7 holdout
  - E8 on two distinct synthetic target identities
- This synthetic validation proves wiring/integrity behavior only. It is **not** evidence that a real local model becomes smarter.
