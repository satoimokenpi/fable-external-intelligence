# Alpha R2 Status

## R2で検証済み

- Python compile: PASS
- Machine-readable JSON/YAML parse: PASS
- Unit / mock self-test: **19 / 19 PASS**
- Full synthetic end-to-end integration: **1,795 completed trial records / 0 failures**
- judge / selector model-call accounting: PASS
- API failure persistence and continue-on-failure: PASS
- complete-dev freeze gate: PASS
- post-freeze config/study/dev-result lock: PASS
- snapshot winner tamper detection: PASS
- raw/result/call-accounting cross-check: PASS
- `json_subset` obligation enforcement: PASS
- dynamic per-repeat task variants: PASS
- E8 one-target no-KEEP gate: PASS
- E8 arbitrary target-tag identity spoof prevention: PASS
- E8 two-distinct-target wiring: PASS
- ground-truth leakage prevention: PASS
- resume / duplicate-count prevention: PASS
- local-only endpoint guard: PASS
- optional post-hoc evaluator import provenance: PASS

## まだ未検証

- 実ローカルLLMでの能力向上率
- モデル規模別の再現性
- 量子化方式別の再現性
- 別runtime間の再現性
- 人手/Jev/別judgeとの評価相関
- 実運用LINKsへの統合効果

## 現在の位置づけ

`TESTER-READY ALPHA R2`

他人にA/Bベンチを回してもらう用途には使用可能です。
「完成品」「Fable相当性能」「必ず性能向上」として配布する段階ではありません。
