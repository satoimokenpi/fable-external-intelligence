# Execution Order — R2

品質差とベンチマーク整合性を分離するため、この順番を崩さないでください。

1. **P0 / E0 — measurement lock**: runtime metadata、sampling、resource policyを固定し、A0 repeatでnoiseを測る。
2. **P1 / E1 — quality reference**: bare と fixed-high referenceをdevで実行。
3. **P2 / E2-E6 — mechanism lift**: devを最低5 repeat。holdoutを見てthresholdを調整しない。
4. **P2.5 / E7 — simplification**: minimal/five-core/full-gatedとcontrolをdevで比較。
5. **Freeze**: `freeze-policy`。R2ではE0-E7の必要dev slotが全部COMPLETEDでなければfreezeできない。config/study/dev digest/winnerも固定する。
6. **Holdout**: E1-E7をholdoutで実行。runnerはfrozen dev winner +必要baselineだけを許可し、freeze後のpolicy/sampling/config改変を拒否する。
7. **E8 transfer**:
   - E7 winnerが `A0_*` controlなら、外付けpolicyはdevで生き残っていないのでE8は実行しない。
   - 外付けpolicyが勝った場合、まず元targetでA0_BARE vs frozen winnerを完走。
   - 次に**実際に異なる**model/quantization/runtime targetで再実行。display用`target_tag`だけ変えても別targetには数えない。
   - whole-policy `KEEP` はcompleteなdistinct targetが2つ以上必要。
8. **Decision**: `analyze`。KEEP / MODEL_CONDITIONED / INCONCLUSIVE / DROPを確認。
9. **Optional evaluator**: rubric/open-ended taskに必要なら `judge-results` または `import-eval`。Objective ground truthは置換しない。

FAILED試行は消えません。後日同じcommandを再実行すると未完slotだけ新しいattemptとして再試行し、過去failureはreliability/resource accountingに残ります。
