# Mock / Integrity Tests — R2

Run:

```powershell
python -m HARNESS.cli self-test
```

R2 contains 19 self-tests covering:

- task strata / E0-E8 definitions
- private ground-truth isolation
- deterministic dynamic task variants
- local-endpoint guard
- objective scoring and `json_subset` obligations
- controller gates
- judge/selector call accounting
- FAILED trial persistence and continue-on-failure
- resume/no-double-count
- strict complete-dev freeze
- frozen config/study lock
- snapshot winner tamper detection
- E8 no-policy control case
- one-target cannot KEEP / two-target wiring
- target-tag identity spoof prevention
- optional external evaluator import provenance

Passing these tests validates harness logic only; it does not imply real-model capability lift.
