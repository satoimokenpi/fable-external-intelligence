import json, shutil, tempfile, unittest
from pathlib import Path

from HARNESS.analyze import analyze, freeze_policy
from HARNESS.backend import validate_local_base_url, BackendError, MockBackend
from HARNESS.evaluation import import_external_eval, evaluation_scores
from HARNESS.controllers import gate, monitor
from HARNESS.integrity import study_definition_hash, target_identity_hash
from HARNESS.runner import TrialRunner
from HARNESS.scoring import offline_score, online_validate
from HARNESS.task_loader import generation_messages, load_manifest, load_task, package_root, public_task_view
from HARNESS.utils import dump_json, load_json


class LiveMockBackend(MockBackend):
    kind='openai_compatible'


class FailingBackend:
    kind='openai_compatible'
    def generate(self,*args,**kwargs):
        raise BackendError('synthetic transport failure')


class EnhancedPolicyBackend(MockBackend):
    """Synthetic live-tagged backend used only to test transfer-gate logic.

    Control baselines are deliberately weak; gated branch/repair paths can recover.
    """
    kind='openai_compatible'
    def generate(self,messages,*,max_tokens,temperature,top_p,seed,meta=None):
        r=super().generate(messages,max_tokens=max_tokens,temperature=temperature,top_p=top_p,seed=seed,meta=meta)
        meta=meta or {}; task=meta.get('task') or {}; label=str(meta.get('label',''))
        good=(task.get('mock') or {}).get('correct_output','MOCK_OK'); bad=(task.get('mock') or {}).get('wrong_output','MOCK_BAD')
        if label=='selector_compare':
            r['text']='{"selected":1,"score":1.0,"reason":"synthetic enhanced selector"}'
        elif label=='branch_1' or label.startswith('repair'):
            r['text']=good
        elif label=='solve' or label.startswith('retry_'):
            r['text']=bad
        return r


class HarnessTests(unittest.TestCase):
    def setUp(self):
        self.root=package_root(); self.cfg=load_json(self.root/'02_RUNTIME_CONFIG_TEMPLATE.json'); self.cfg['backend']['model']='MOCK'
        self.cfg['model_metadata']['model_id']='MOCK'; self.cfg['model_metadata']['quantization']='TEST'; self.cfg['experiment']['feature_mode']='annotated'
        self._run_ids=[]
    def tearDown(self):
        for rid in self._run_ids:
            p=self.root/'RUNS'/rid
            if p.exists(): shutil.rmtree(p)
    def rid(self,name):
        rid='__selftest_'+name+'__'; self._run_ids.append(rid); p=self.root/'RUNS'/rid
        if p.exists(): shutil.rmtree(p)
        return rid

    def test_e0_e8_present(self):
        arms=load_json(self.root/'03_EXPERIMENT_ARMS.yaml')
        self.assertEqual(set(arms['experiments']),{'E0_MEASUREMENT_NOISE','E1_QUALITY_REFERENCE','E2_COMPUTE_CONTROL','E3_VERIFICATION_TRUST','E4_PLANNING_AND_SCAFFOLD_GATE','E5_BRANCH_AND_ADVISOR','E6_LONG_LOOP_COMPLETION','E7_CORE_SIMPLIFICATION','E8_TRANSFER'})

    def test_all_required_strata_covered_both_splits(self):
        man=load_manifest(); req=set(man['required_strata'])
        for split in ('dev','holdout'):
            got=set()
            for p in (self.root/'TASKS'/split).glob('*.json'): got.update(load_json(p)['strata'])
            self.assertTrue(req.issubset(got), (split,req-got))

    def test_ground_truth_not_in_messages(self):
        t=load_task('D01_SIMPLE_ARITH','dev',variant_seed=1); msgs=generation_messages(t); raw=json.dumps(msgs)
        self.assertNotIn('private_evaluation',raw); self.assertNotIn('mock',raw); self.assertNotIn('expected_triggers',raw); self.assertNotIn('online_validator',raw); self.assertNotIn('variant_generator',raw)
        self.assertEqual(set(public_task_view(t)).intersection({'private_evaluation','mock'}),set())

    def test_dynamic_variants_are_repeatable_and_nonconstant(self):
        a=load_task('D01_SIMPLE_ARITH','dev',variant_seed=100)
        b=load_task('D01_SIMPLE_ARITH','dev',variant_seed=100)
        c=load_task('D01_SIMPLE_ARITH','dev',variant_seed=101)
        self.assertEqual(a['prompt'],b['prompt']); self.assertEqual(a['private_evaluation'],b['private_evaluation'])
        self.assertNotEqual((a['prompt'],a['private_evaluation']),(c['prompt'],c['private_evaluation']))

    def test_local_endpoint_guard(self):
        self.assertTrue(validate_local_base_url('http://127.0.0.1:1234/v1'))
        with self.assertRaises(BackendError): validate_local_base_url('https://api.example.com/v1')

    def test_target_identity_cannot_be_faked_by_target_tag_only(self):
        a=json.loads(json.dumps(self.cfg)); b=json.loads(json.dumps(self.cfg))
        a.setdefault('transfer',{})['target_tag']='A'; b.setdefault('transfer',{})['target_tag']='B'
        self.assertEqual(target_identity_hash(a),target_identity_hash(b))
        b['model_metadata']['quantization']='OTHER_QUANT'
        self.assertNotEqual(target_identity_hash(a),target_identity_hash(b))

    def test_scoring_and_online_validator(self):
        t=load_task('D03_DEPENDENT_CHAIN','dev'); self.assertTrue(offline_score(t,'41')['passed']); self.assertFalse(offline_score(t,'40')['passed']); self.assertTrue(online_validate(t,'41')['passed'])

    def test_json_subset_requires_all_obligations(self):
        t=load_task('D09_LONG_OBLIGATIONS','dev')
        out='{"owner":"Mina","deadline":"Friday 17:00","risk":"database migration rollback failure","mitigation":"tested rollback rehearsal before cutover"}'
        s=offline_score(t,out)
        self.assertEqual(s['content_score'],1.0); self.assertEqual(s['completion_rate'],0.8); self.assertEqual(s['score'],0.8); self.assertFalse(s['passed'])

    def test_gate_negative_and_positive(self):
        s=load_task('D01_SIMPLE_ARITH','dev'); h=load_task('D06_SEPARABLE_EVIDENCE','dev')
        self.assertFalse(gate(monitor(s,self.cfg),self.cfg)['decompose']); self.assertTrue(gate(monitor(h,self.cfg),self.cfg)['decompose'])

    def test_judge_and_selector_calls_are_counted(self):
        rid=self.rid('callcount'); r=TrialRunner(self.cfg,MockBackend(),rid)
        task=load_task('D05_UNCHECKABLE_TRADEOFF','dev',variant_seed=11)
        arm=r.arm_by_id['A6_INDEPENDENT_N4']
        final,features,gate_rec,actions,events,res,calls=r.execute_strategy(task,arm,0)
        self.assertEqual(res['inference_call_attempts'],5)  # 4 branches + fresh selector call
        self.assertEqual(len(calls),5); self.assertTrue(any(c['label']=='selector_compare' for c in calls))
        arm2=r.arm_by_id['A4_FRESH_JUDGE']
        _,_,_,_,_,res2,calls2=r.execute_strategy(task,arm2,0)
        self.assertEqual(res2['inference_call_attempts'],2)  # solve + fresh judge
        self.assertTrue(any(c['label']=='judge_fresh' for c in calls2))

    def test_api_failure_becomes_failed_trial_with_cost_and_does_not_raise(self):
        rid=self.rid('failure'); r=TrialRunner(self.cfg,FailingBackend(),rid)
        rec=r.run_trial('E1_QUALITY_REFERENCE','A0_BARE','D01_SIMPLE_ARITH','dev',0)
        self.assertEqual(rec['status'],'FAILED'); self.assertEqual(rec['resources']['inference_call_attempts'],1)
        self.assertEqual(rec['resources']['failed_inference_calls'],1); self.assertGreater(rec['resources']['attempted_output_token_cap'],0)
        self.assertGreater(rec['resources']['estimated_input_tokens'],0); self.assertIsNotNone(rec['failure'])

    def test_experiment_continues_after_api_failures(self):
        rid=self.rid('failure_matrix'); r=TrialRunner(self.cfg,FailingBackend(),rid)
        out=r.run_experiment('E0_MEASUREMENT_NOISE','dev',5)
        self.assertEqual(out['completed'],0); self.assertEqual(out['failed'],out['scheduled']); self.assertGreater(out['failed'],1)
        rows=[json.loads(x) for x in (self.root/'RUNS'/rid/'results.jsonl').read_text().splitlines() if x.strip()]
        self.assertEqual(len(rows),out['failed']); self.assertTrue(all(x['status']=='FAILED' for x in rows))
        self.assertTrue(all(x['resources']['inference_call_attempts']>=1 for x in rows))

    def test_mock_trial_resume_key(self):
        rid=self.rid('resume'); r=TrialRunner(self.cfg,MockBackend(),rid); out=r.run_experiment('E0_MEASUREMENT_NOISE','dev',5)
        self.assertGreater(out['completed'],0); out2=r.run_experiment('E0_MEASUREMENT_NOISE','dev',5); self.assertEqual(out2['completed'],0); self.assertEqual(out2['skipped'],out2['scheduled'])
        rows=[json.loads(x) for x in (self.root/'RUNS'/rid/'results.jsonl').read_text().splitlines() if x.strip()]
        self.assertEqual(len(rows),len({x['trial_key'] for x in rows})); self.assertTrue(all(x['mock_only'] for x in rows))
        a=analyze(rid); self.assertIn('decision_table',a); self.assertTrue(all(v['classification']=='INCONCLUSIVE' for v in a['decision_table']['controllers'].values()))

    def test_external_evaluator_import_is_posthoc_and_provenanced(self):
        rid=self.rid('external_eval'); r=TrialRunner(self.cfg,LiveMockBackend(),rid)
        r.run_experiment('E1_QUALITY_REFERENCE','dev',5)
        rows=[json.loads(x) for x in (self.root/'RUNS'/rid/'results.jsonl').read_text().splitlines() if x.strip()]
        tk=next(x['trial_key'] for x in rows if x['status']=='COMPLETED')
        inp=self.root/'RUNS'/rid/'jev_fixture.jsonl'
        inp.write_text(json.dumps({'trial_key':tk,'score':0.75,'passed':True,'confidence':0.8,'reason':'fixture'})+'\n',encoding='utf-8')
        out=import_external_eval(rid,inp,'jev')
        self.assertEqual(out['added'],1); self.assertTrue(out['source_file_sha256']); self.assertTrue(out['import_batch_hash'])
        scores=evaluation_scores(rid); self.assertAlmostEqual(scores[tk]['mean_score'],0.75); self.assertIn('jev',scores[tk]['sources'])

    def test_freeze_rejects_incomplete_dev(self):
        rid=self.rid('freeze_incomplete'); r=TrialRunner(self.cfg,MockBackend(),rid); r.run_experiment('E0_MEASUREMENT_NOISE','dev',5)
        cfgp=self.root/'RUNS'/rid/'cfg.json'; dump_json(cfgp,self.cfg)
        with self.assertRaises(RuntimeError): freeze_policy(rid,cfgp,allow_mock=True)

    def _complete_mock_dev_and_freeze(self,rid):
        r=TrialRunner(self.cfg,MockBackend(),rid)
        for eid in ['E0_MEASUREMENT_NOISE','E1_QUALITY_REFERENCE','E2_COMPUTE_CONTROL','E3_VERIFICATION_TRUST','E4_PLANNING_AND_SCAFFOLD_GATE','E5_BRANCH_AND_ADVISOR','E6_LONG_LOOP_COMPLETION','E7_CORE_SIMPLIFICATION']:
            r.run_experiment(eid,'dev',5)
        cfgp=self.root/'RUNS'/rid/'cfg.json'; dump_json(cfgp,self.cfg)
        snap=freeze_policy(rid,cfgp,allow_mock=True)
        return r,snap,cfgp

    def test_freeze_locks_config_and_study(self):
        rid=self.rid('freeze_lock'); r,snap,cfgp=self._complete_mock_dev_and_freeze(rid)
        self.assertEqual(snap['study_definition_hash'],study_definition_hash(self.root)); self.assertEqual(snap['required_dev_slot_count'],len(snap['required_dev_slots']))
        changed=json.loads(json.dumps(self.cfg)); changed['policy']['high_constraint_count']=99
        r2=TrialRunner(changed,MockBackend(),rid)
        with self.assertRaises(RuntimeError): r2.run_experiment('E1_QUALITY_REFERENCE','holdout',5)
        with self.assertRaises(RuntimeError): r.run_experiment('E1_QUALITY_REFERENCE','dev',5)

    def test_e8_is_not_run_when_e7_selects_control_baseline(self):
        rid=self.rid('e8_no_policy'); r,snap,_=self._complete_mock_dev_and_freeze(rid)
        self.assertTrue(str(snap['e7_winner']).startswith('A0_'))
        a=analyze(rid)
        self.assertEqual(a['e8_transfer_status'],'NO_EXTERNAL_POLICY_SURVIVED_DEV')
        self.assertEqual(a['decision_table']['frozen_policy']['classification'],'DROP')
        with self.assertRaises(RuntimeError): r.run_experiment('E8_TRANSFER','holdout',5)

    def _complete_live_enhanced_dev_and_freeze(self,rid):
        cfg=json.loads(json.dumps(self.cfg)); cfg['backend']['model']='SYNTH_A'; cfg['model_metadata']['model_id']='SYNTH_A'; cfg['model_metadata']['quantization']='Q4_TEST'
        r=TrialRunner(cfg,EnhancedPolicyBackend(),rid)
        for eid in ['E0_MEASUREMENT_NOISE','E1_QUALITY_REFERENCE','E2_COMPUTE_CONTROL','E3_VERIFICATION_TRUST','E4_PLANNING_AND_SCAFFOLD_GATE','E5_BRANCH_AND_ADVISOR','E6_LONG_LOOP_COMPLETION','E7_CORE_SIMPLIFICATION']:
            r.run_experiment(eid,'dev',5)
        cfgp=self.root/'RUNS'/rid/'cfg.live.json'; dump_json(cfgp,cfg)
        snap=freeze_policy(rid,cfgp)
        self.assertTrue(str(snap['e7_winner']).startswith('A10_'), snap['e7_winner'])
        return cfg,r,snap,cfgp

    def test_e8_one_target_never_keep_and_two_real_targets_required(self):
        rid=self.rid('e8_transfer'); cfg,r,snap,_=self._complete_live_enhanced_dev_and_freeze(rid)
        out=r.run_experiment('E8_TRANSFER','holdout',5); self.assertGreater(out['completed'],0)
        a=analyze(rid); self.assertEqual(a['e8_complete_target_count'],1); self.assertNotEqual(a['decision_table']['frozen_policy']['classification'],'KEEP')
        cfg2=json.loads(json.dumps(cfg)); cfg2['backend']['model']='SYNTH_B'; cfg2['model_metadata']['model_id']='SYNTH_B'; cfg2['transfer']['target_tag']='second'
        r2=TrialRunner(cfg2,EnhancedPolicyBackend(),rid); out2=r2.run_experiment('E8_TRANSFER','holdout',5); self.assertGreater(out2['completed'],0)
        a2=analyze(rid); self.assertEqual(a2['e8_complete_target_count'],2)

    def test_snapshot_winner_tampering_is_detected(self):
        rid=self.rid('snapshot_tamper'); cfg,r,snap,_=self._complete_live_enhanced_dev_and_freeze(rid)
        sp=self.root/'RUNS'/rid/'POLICY_SNAPSHOT.json'; obj=load_json(sp); obj['e7_winner']='A0_BARE'; dump_json(sp,obj)
        r2=TrialRunner(cfg,EnhancedPolicyBackend(),rid)
        with self.assertRaises(RuntimeError): r2.run_experiment('E1_QUALITY_REFERENCE','holdout',5)




if __name__=='__main__': unittest.main()
