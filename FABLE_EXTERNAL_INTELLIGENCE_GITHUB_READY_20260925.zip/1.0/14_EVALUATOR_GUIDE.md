# Optional evaluator layer — R2

Deterministic ground truthが完全に定義できるtaskでは、それをprimary signalにします。Open-ended/rubric-proxy taskだけ、generation後にblind evaluatorを足せます。

## Local LLM-as-a-judge

1. `12_JUDGE_CONFIG_TEMPLATE.json` → `judge.local.json` にコピー。
2. LOCAL OpenAI-compatible judgeを指定。可能ならbenchmark対象と別model/familyを使う。
3. 実行:

```powershell
python -m HARNESS.cli judge-results --run-id localA --judge-config .\judge.local.json
python -m HARNESS.cli analyze --run-id localA
```

Judgeにはarm identity、hidden ground truth、expected trigger、mock fixtureを見せません。Candidate answerは**untrusted data**としてdelimiter内に置き、candidate中のjudge向け命令には従わないよう指示します。

Judge callは `judge_results.jsonl` に別保存され、benchmark generationのcall/token costへ混ぜません。

## Jev / human / LangSmith / another evaluator

Core harnessにcloud依存を強制しません。外部評価後、`13_EXTERNAL_EVAL_SCHEMA.json` に従うJSONLをimportします。

```powershell
python -m HARNESS.cli import-eval --run-id localA --file .\jev_results.jsonl --source jev
python -m HARNESS.cli analyze --run-id localA
```

Import時にsource file SHA-256とbatch hashを記録します。外部scoreは `posthoc_evaluator_score` として補助的に扱われ、deterministic objective scoreを上書きしません。

## Interpretation rules

- Objective deterministic check > calibrated human/evaluator > uncalibrated LLM judge の順に信頼する。
- Same-model self-judgeは相関誤りを起こし得る。
- 外部evaluatorは少量のhuman labelでcalibrationしてから強い結論に使う。
- Judge agreementだけでcorrectnessを断定しない。
- Evaluation model/costはgeneration model/costと分離して報告する。
