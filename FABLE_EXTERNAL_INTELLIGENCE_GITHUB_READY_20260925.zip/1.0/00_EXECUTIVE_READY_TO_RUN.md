# Fable -> LINKs External Intelligence Validation Harness — Alpha R2

**Stage:** local-model A/B validation
**Build:** 2026-09-25 R2 integrity repair
**Empirical real-model lift:** **PENDING_USER_LOCAL_RUN**
**Weights / architecture changes:** **NONE**

This package tests whether externally controllable reasoning policies improve an already-loaded local LLM. It does not claim to reproduce private Fable internals.

## Five external controller abstractions

1. Task / Evidence State Monitor
2. Compute Controller
3. Scaffold Action Gate
4. Verification / Trust Controller
5. Completion / Stop Controller

Planning, decomposition, branches, debate, advisor passes, verification, repair and long-loop behavior are tactics behind these controllers rather than permanent modules.

## R2 benchmark-integrity repair

External review found five real flaws in the Alpha benchmark. R2 closes all five:

- judge/selector calls now count as model calls and usage;
- freeze requires a complete, internally consistent dev study and holdout re-verifies it;
- E8 cannot call a whole policy KEEP from one target;
- API failures persist as FAILED attempts and do not abort the full matrix;
- missing declared obligations prevent `json_subset` PASS.

R2 additionally adds per-repeat objective task variants, optional blind local LLM judging, generic Jev/human/external evaluator import, raw/result/resource consistency checks, snapshot winner recomputation, and target-identity hardening. See `15_R2_FIX_CHANGELOG.md`.

## Evidence hierarchy

- Deterministic objective ground truth is primary where available.
- Rubric/open-ended tasks are reported separately.
- Optional post-hoc evaluators may supplement subjective tasks but never overwrite objective ground truth.
- Mock/synthetic results are harness evidence only, never model-quality evidence.

## R2 validation

- Self-tests: **19/19 PASS**
- Full synthetic end-to-end integration: **1,795 completed trial records / 0 failures**
- Flow exercised: E0-E7 dev -> strict freeze -> E1-E7 holdout -> E8 two distinct synthetic targets
- Live LM Studio/local model trials: **PENDING_USER_LOCAL_RUN**

The next evidence-producing step is a real local-model run using `11_RUN_LOCAL_INSTRUCTIONS.md`.
