from __future__ import annotations
import ipaddress, json, socket, urllib.parse, urllib.request, urllib.error, time
from .utils import estimate_tokens

class BackendError(RuntimeError): pass

def _is_local_host(host):
    if not host: return False
    h=host.lower()
    if h in {'localhost','127.0.0.1','::1'}: return True
    try:
        ip=ipaddress.ip_address(h)
        return ip.is_loopback or ip.is_private
    except ValueError:
        try:
            infos=socket.getaddrinfo(host,None)
            return bool(infos) and all(ipaddress.ip_address(x[4][0]).is_loopback or ipaddress.ip_address(x[4][0]).is_private for x in infos)
        except Exception:
            return False

def validate_local_base_url(url):
    u=urllib.parse.urlparse(url)
    if u.scheme not in {'http','https'}: raise BackendError('Only http/https local endpoints are allowed')
    if not _is_local_host(u.hostname): raise BackendError('Public/provider endpoint rejected: local loopback/private-LAN host required')
    return url.rstrip('/')

class OpenAICompatibleBackend:
    kind='openai_compatible'
    def __init__(self, cfg):
        self.cfg=cfg
        self.base=validate_local_base_url(cfg['base_url'])
        self.model=cfg['model']
        if not self.model or self.model.startswith('SET_'): raise BackendError('Set backend.model in runtime config')
        self.timeout=float(cfg.get('timeout_seconds',180))
        self.send_seed=bool(cfg.get('send_seed',True))
    def probe(self):
        req=urllib.request.Request(self.base+'/models', method='GET')
        with urllib.request.urlopen(req, timeout=min(self.timeout,10)) as r:
            return json.loads(r.read().decode('utf-8'))
    def generate(self, messages, *, max_tokens, temperature, top_p, seed, meta=None):
        body={'model':self.model,'messages':messages,'temperature':temperature,'top_p':top_p,'max_tokens':int(max_tokens),'stream':False}
        if self.send_seed and seed is not None: body['seed']=int(seed)
        req=urllib.request.Request(self.base+'/chat/completions', data=json.dumps(body).encode('utf-8'), headers={'Content-Type':'application/json'}, method='POST')
        t=time.perf_counter()
        try:
            with urllib.request.urlopen(req, timeout=self.timeout) as r: data=json.loads(r.read().decode('utf-8'))
        except urllib.error.HTTPError as e:
            detail=e.read().decode('utf-8',errors='replace')
            raise BackendError(f'HTTP {e.code}: {detail[:500]}')
        elapsed=time.perf_counter()-t
        try: text=data['choices'][0]['message']['content']
        except Exception as exc: raise BackendError(f'Unexpected response shape: {data}') from exc
        usage=data.get('usage') or {}
        return {'text':text,'elapsed_seconds':elapsed,'usage':usage,'raw':data}

class MockBackend:
    kind='mock'
    def __init__(self): self.calls=[]
    def probe(self): return {'object':'list','data':[{'id':'MOCK_ONLY'}]}
    def generate(self, messages, *, max_tokens, temperature, top_p, seed, meta=None):
        meta=meta or {}; task=meta.get('task') or {}; label=str(meta.get('label',''))
        good=(task.get('mock') or {}).get('correct_output','MOCK_OK')
        bad=(task.get('mock') or {}).get('wrong_output','MOCK_BAD')
        candidate=meta.get('candidate','')
        if 'selector_compare' in label:
            text=json.dumps({'selected':0,'score':1.0,'reason':'mock comparison fixture'}, separators=(',',':'))
        elif 'judge' in label or 'selector' in label:
            verdict='PASS' if candidate.strip()==good.strip() else 'FAIL'
            text=json.dumps({'verdict':verdict,'score':1.0 if verdict=='PASS' else 0.0,'reason':'mock fixture'}, separators=(',',':'))
        elif 'plan' in label: text='Mock plan: preserve obligations; solve; verify.'
        elif 'spec' in label or 'orientation' in label: text='Mock orientation/specification: identify constraints and acceptance criteria.'
        elif 'advisor' in label: text='Mock advisor: verify the highest-risk decision before finalizing.'
        elif 'critique' in label or 'repair' in label or 'synthesis' in label: text=good
        elif 'branch_1' in label or 'branch_3' in label or 'retry_1' in label: text=bad
        else: text=good
        rec={'messages':messages,'meta':{k:v for k,v in meta.items() if k!='task'},'text':text}
        self.calls.append(rec)
        return {'text':text,'elapsed_seconds':0.0001,'usage':{'prompt_tokens':estimate_tokens(json.dumps(messages)),'completion_tokens':estimate_tokens(text),'total_tokens':estimate_tokens(json.dumps(messages))+estimate_tokens(text)},'raw':{'mock':True}}
