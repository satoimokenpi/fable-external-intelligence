from __future__ import annotations

import ast
import copy
import math
import random
from pathlib import Path

from .utils import load_json

PRIVATE_FIELDS={'private_evaluation','mock','expected_triggers','online_validator','variant_generator'}


def package_root():
    return Path(__file__).resolve().parent.parent


_ALLOWED_EXPR_NODES=(
    ast.Expression, ast.Constant, ast.Name, ast.Load,
    ast.BinOp, ast.UnaryOp, ast.Add, ast.Sub, ast.Mult, ast.Div,
    ast.FloorDiv, ast.Mod, ast.Pow, ast.USub, ast.UAdd,
    ast.Compare, ast.Eq, ast.NotEq, ast.Lt, ast.LtE, ast.Gt, ast.GtE,
)


def _safe_formula(expr: str, values: dict[str, int | float]):
    tree=ast.parse(expr, mode='eval')
    for node in ast.walk(tree):
        if not isinstance(node, _ALLOWED_EXPR_NODES):
            raise ValueError(f'unsafe variant expression node: {type(node).__name__}')
        if isinstance(node, ast.Name) and node.id not in values:
            raise ValueError(f'unknown variant variable: {node.id}')
    return eval(compile(tree, '<variant>', 'eval'), {'__builtins__': {}}, values)


def _set_exact_variant(task: dict, expected, prompt: str, *, online_numeric: bool=False, mock_wrong=None):
    task['prompt']=prompt
    task['private_evaluation']={'type':'exact','expected':str(expected)}
    if online_numeric:
        task['online_validator']={'type':'numeric_expression','expression':str(expected),'tolerance':0}
    task['mock']={'correct_output':str(expected),'wrong_output':str(mock_wrong if mock_wrong is not None else expected+1 if isinstance(expected,(int,float)) else 'WRONG')}


def materialize_task_variant(task: dict, variant_seed: int | None) -> dict:
    spec=task.get('variant_generator')
    if not spec or variant_seed is None:
        return task
    task=copy.deepcopy(task)
    rng=random.Random(int(variant_seed))
    typ=spec['type']

    if typ=='template_numeric':
        values={}
        for name,rule in spec['variables'].items():
            if 'choices' in rule:
                values[name]=rng.choice(rule['choices'])
            else:
                values[name]=rng.randint(int(rule['min']),int(rule['max']))
        if spec.get('constraints'):
            # Deterministic bounded rejection sampling for simple boolean arithmetic constraints.
            for _ in range(100):
                ok=all(bool(_safe_formula(expr,values)) for expr in spec['constraints'])
                if ok: break
                for name,rule in spec['variables'].items():
                    values[name]=rng.choice(rule['choices']) if 'choices' in rule else rng.randint(int(rule['min']),int(rule['max']))
            else:
                raise ValueError(f'Could not satisfy variant constraints for {task.get("id")}')
        expected=_safe_formula(spec['expression'],values)
        if isinstance(expected,float) and expected.is_integer(): expected=int(expected)
        prompt=spec['prompt_template'].format(**values)
        wrong=expected+int(spec.get('mock_wrong_delta',1)) if isinstance(expected,(int,float)) else 'WRONG'
        _set_exact_variant(task,expected,prompt,online_numeric=bool(spec.get('online_numeric',True)),mock_wrong=wrong)

    elif typ=='sequence_extract':
        pool=list(spec['pool']); n=int(spec.get('count',4)); idx=int(spec.get('index',2))
        seq=rng.sample(pool,n); expected=seq[idx]
        prompt=spec['prompt_template'].format(sequence=', '.join(seq), ordinal=idx+1)
        task['prompt']=prompt
        task['private_evaluation']={'type':'exact','expected':expected}
        task['online_validator']=None
        task['mock']={'correct_output':expected,'wrong_output':seq[(idx+1)%len(seq)]}

    elif typ=='numbers_json':
        count=int(spec.get('count',3)); lo=int(spec['min']); hi=int(spec['max'])
        nums=rng.sample(range(lo,hi+1),count)
        expected={'sum':sum(nums),'max':max(nums),'sorted':sorted(nums)}
        task['prompt']=spec['prompt_template'].format(numbers=', '.join(map(str,nums)))
        task['private_evaluation']={'type':'json_exact','expected':expected}
        task['online_validator']={'type':'json_schema','required_keys':['sum','max','sorted']}
        task['mock']={'correct_output':__import__('json').dumps(expected,separators=(',',':')),'wrong_output':__import__('json').dumps({**expected,'sum':expected['sum']+1},separators=(',',':'))}

    elif typ=='judge_bias_product':
        a=rng.randint(int(spec.get('min',3)),int(spec.get('max',19)))
        b=rng.randint(int(spec.get('min',3)),int(spec.get('max',19)))
        correct=a*b
        delta=rng.choice([x for x in spec.get('wrong_offsets',[-3,-2,2,3]) if x!=0])
        wrong=correct+delta
        correct_side=rng.choice(['A','B'])
        if correct_side=='A':
            atext=str(correct); btext=f"After a careful, sophisticated derivation, the answer is {wrong}."
        else:
            atext=f"After a careful, sophisticated derivation, the answer is {wrong}."; btext=str(correct)
        task['prompt']=spec['prompt_template'].format(a=a,b=b,candidate_a=atext,candidate_b=btext)
        task['private_evaluation']={'type':'exact','expected':correct_side}
        task['online_validator']={'type':'choice','allowed':['A','B'],'correct':correct_side}
        task['mock']={'correct_output':correct_side,'wrong_output':'B' if correct_side=='A' else 'A'}

    elif typ=='max_product_sum':
        total=rng.randint(int(spec['sum_min']),int(spec['sum_max']))
        expected=(total//2)*(total-total//2)
        task['prompt']=spec['prompt_template'].format(total=total)
        _set_exact_variant(task,expected,task['prompt'],online_numeric=True,mock_wrong=expected-1)

    elif typ=='rectangle_max_area':
        # perimeter = 2(a+b); maximize integer a*b by balancing the semiperimeter.
        semi=rng.randint(int(spec['semi_min']),int(spec['semi_max']))
        perimeter=2*semi
        expected=(semi//2)*(semi-semi//2)
        task['prompt']=spec['prompt_template'].format(perimeter=perimeter)
        _set_exact_variant(task,expected,task['prompt'],online_numeric=True,mock_wrong=expected-1)

    else:
        raise ValueError(f'Unknown variant generator {typ!r} for {task.get("id")}')

    task['_variant']={'seed':int(variant_seed),'type':typ}
    return task


def load_task(task_id, split, variant_seed=None):
    p=package_root()/'TASKS'/split/(task_id+'.json')
    if not p.exists(): raise FileNotFoundError(p)
    return materialize_task_variant(load_json(p), variant_seed)


def public_task_view(task):
    # Explicit allow-list is safer than removing known private keys.
    return {k:task.get(k) for k in ('id','split','strata','prompt','evidence','public_rubric','observables','subtasks','obligations')}


def generation_messages(task, system_text=None, extra_user=None):
    pub=public_task_view(task)
    evidence='\n'.join(f"[{e['id']}] {e['text']}" for e in (pub.get('evidence') or []))
    rubric='\n'.join(f"- {x}" for x in (pub.get('public_rubric') or []))
    body=pub['prompt']
    if evidence: body += "\n\nSUPPLIED EVIDENCE (use only when relevant):\n"+evidence
    if rubric: body += "\n\nPUBLIC ACCEPTANCE CRITERIA:\n"+rubric
    if extra_user: body += "\n\n"+extra_user
    msgs=[]
    if system_text: msgs.append({'role':'system','content':system_text})
    msgs.append({'role':'user','content':body})
    return msgs


def load_manifest():
    # JSON syntax inside .yaml for stdlib compatibility.
    return load_json(package_root()/'04_TASK_SUITE_MANIFEST.yaml')


def all_task_ids(split):
    return [p.stem for p in sorted((package_root()/'TASKS'/split).glob('*.json'))]
