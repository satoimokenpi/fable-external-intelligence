from __future__ import annotations

import json, statistics
from collections import defaultdict
from pathlib import Path

from .evaluation import evaluation_scores
from .integrity import (
    completed_by_slot, dev_results_digest, load_results, record_slot_key,
    required_dev_slots, runtime_config_hash, study_definition_hash, validate_trial_record_integrity,
)
from .task_loader import package_root
from .utils import canonical_hash, dump_json, load_json, file_sha256, now_utc


def _mean(vals):
    vals=[v for v in vals if v is not None]
    return sum(vals)/len(vals) if vals else None


def _std(vals):
    vals=[v for v in vals if v is not None]
    return statistics.stdev(vals) if len(vals)>1 else 0.0 if vals else None


def _quality_rows(rows):
    """One completed record per scheduled slot; failed attempts remain available for reliability/cost stats."""
    return list(completed_by_slot(rows).values())


def _attempt_group_key(r):
    return (r.get('experiment_id'),r.get('arm_id'),r.get('split'),r.get('config_hash'))


def _target_id(r):
    return r.get('target_identity_hash') or r.get('config_hash') or 'unknown'


def analyze(run_id):
    root=package_root(); rdir=root/'RUNS'/run_id; rp=rdir/'results.jsonl'
    if not rp.exists(): raise FileNotFoundError(rp)
    rows=load_results(rp)
    live_attempts=[r for r in rows if not r.get('mock_only')]
    has_live_attempts=bool(live_attempts)
    attempt_data=live_attempts if has_live_attempts else rows
    completed_all=_quality_rows(rows)
    live_completed=[r for r in completed_all if not r.get('mock_only')]
    data=live_completed if has_live_attempts else completed_all
    eval_by_trial=evaluation_scores(run_id)

    grouped=defaultdict(list)
    for r in data: grouped[_attempt_group_key(r)].append(r)
    attempts_grouped=defaultdict(list)
    for r in attempt_data: attempts_grouped[_attempt_group_key(r)].append(r)

    summary={}
    all_group_keys=set(grouped)|set(attempts_grouped)
    for (eid,aid,split,ch) in sorted(all_group_keys, key=lambda x: tuple(str(y) for y in x)):
        rs=grouped.get((eid,aid,split,ch),[])
        objective=[r for r in rs if (r.get('offline_score') or {}).get('verification_strength')=='objective']
        rub=[r for r in rs if (r.get('offline_score') or {}).get('verification_strength')=='rubric_proxy']
        ats=attempts_grouped.get((eid,aid,split,ch),[])
        posthoc=[]
        for r in rs:
            e=eval_by_trial.get(r.get('trial_key'))
            if e and e.get('mean_score') is not None: posthoc.append(e['mean_score'])
        completed_slots={record_slot_key(r) for r in rs}
        attempted_slots={record_slot_key(r) for r in ats}
        call_attempts=sum(int((r.get('resources') or {}).get('inference_call_attempts',(r.get('resources') or {}).get('inference_calls',0)) or 0) for r in ats)
        failed_attempts=sum(1 for r in ats if r.get('status')=='FAILED')
        s={
          'n':len(rs),'completed_n':len(rs),'attempt_n':len(ats),'failed_attempt_n':failed_attempts,
          'trial_failure_rate':failed_attempts/max(1,len(ats)),
          'objective_n':len(objective),'verified_task_success':_mean([(r.get('offline_score') or {}).get('score') for r in objective]),
          'rubric_quality_score':_mean([(r.get('offline_score') or {}).get('score') for r in rub]),
          'posthoc_evaluator_score':_mean(posthoc),'posthoc_evaluator_n':len(posthoc),
          'completion_rate':_mean([(r.get('offline_score') or {}).get('completion_rate',1) for r in rs]),
          'false_pass_rate':_mean([1.0 if r.get('false_pass') else 0.0 for r in rs]),
          'trigger_precision':_mean([(r.get('trigger_metrics') or {}).get('trigger_precision') for r in rs]),
          'trigger_recall':_mean([(r.get('trigger_metrics') or {}).get('trigger_recall') for r in rs]),
          'gate_prediction_precision':_mean([(r.get('gate_prediction_metrics') or {}).get('trigger_precision',1.0) for r in rs]),
          'gate_prediction_recall':_mean([(r.get('gate_prediction_metrics') or {}).get('trigger_recall',1.0) for r in rs]),
          'mean_calls':call_attempts/max(1,len(attempted_slots)),
          'mean_calls_per_completed_slot':call_attempts/max(1,len(completed_slots)) if completed_slots else None,
          'total_call_attempts':call_attempts,
          'total_reported_input_tokens':sum(int((r.get('resources') or {}).get('reported_input_tokens') or 0) for r in ats),
          'total_reported_output_tokens':sum(int((r.get('resources') or {}).get('reported_output_tokens') or 0) for r in ats),
          'total_estimated_input_tokens':sum(int((r.get('resources') or {}).get('estimated_input_tokens') or 0) for r in ats),
          'total_estimated_output_tokens':sum(int((r.get('resources') or {}).get('estimated_output_tokens') or 0) for r in ats),
          'mean_estimated_output_tokens':_mean([(r.get('resources') or {}).get('estimated_output_tokens') for r in rs]),
          'mean_elapsed_seconds':sum(float((r.get('resources') or {}).get('elapsed_seconds') or 0) for r in ats)/max(1,len(attempted_slots)),
          'backend_model':(rs[0] if rs else ats[0]).get('backend_model'),'transfer_target_tag':(rs[0] if rs else ats[0]).get('transfer_target_tag'),
          'target_identity_hash':_target_id(rs[0] if rs else ats[0]),
        }
        subjective=s['posthoc_evaluator_score'] if s['posthoc_evaluator_score'] is not None else s['rubric_quality_score']
        s['subjective_quality_score']=subjective
        summary[f'{eid}|{aid}|{split}|{ch[:12] if ch else "none"}']=s

    bytask=defaultdict(list)
    for r in data:
        if r.get('experiment_id')=='E0_MEASUREMENT_NOISE' and (r.get('offline_score') or {}).get('verification_strength')=='objective':
            bytask[r['task_id']].append(r['offline_score']['score'])
    task_stds={k:_std(v) for k,v in bytask.items()}; noise=max(task_stds.values()) if task_stds else None

    arms=load_json(root/'03_EXPERIMENT_ARMS.yaml'); manifest=load_json(root/'04_TASK_SUITE_MANIFEST.yaml')
    complexity={a['id']:a.get('complexity',99) for a in arms['arms']}
    snapshot=load_json(rdir/'POLICY_SNAPSHOT.json') if (rdir/'POLICY_SNAPSHOT.json').exists() else None
    min_reps=int((snapshot or {}).get('minimum_repetitions') or 5)

    selected={}
    dev_hashes=[]
    for r in data:
        if r.get('split')=='dev' and r.get('config_hash') not in dev_hashes: dev_hashes.append(r.get('config_hash'))
    primary_hash=(snapshot or {}).get('config_hash') or (dev_hashes[0] if dev_hashes else None)
    for eid in arms['experiments']:
        cands=[]
        for key,s in summary.items():
            ee,aa,sp,ch12=key.split('|')
            if ee==eid and sp=='dev' and s['n']>0 and (primary_hash is None or ch12==primary_hash[:12]):
                q=s['verified_task_success']; q=-1.0 if q is None else q
                subj=s['subjective_quality_score']; subj=-1.0 if subj is None else subj
                cands.append((q,subj,s['completion_rate'] or 0,-s['trial_failure_rate'],-(s['mean_calls'] or 999),-complexity.get(aa,99),aa))
        if cands:selected[eid]=max(cands)[-1]
    e7=(snapshot or {}).get('e7_winner') or selected.get('E7_CORE_SIMPLIFICATION')

    def _expected_per_arm(eid,split):
        return len(manifest['experiment_tasks'].get(eid,{}).get(split,[]))*min_reps

    def _group_values(eid,aid,split):
        vals=[]
        for k,v in summary.items():
            ee,aa,sp,_=k.split('|')
            if ee==eid and aa==aid and sp==split:
                vals.append(v)
        return vals

    def group_value(eid,aid,split,require_complete=False):
        vals=_group_values(eid,aid,split)
        if not vals:return None
        if require_complete:
            needed=_expected_per_arm(eid,split)
            vals=[v for v in vals if v.get('n',0)>=needed]
            if not vals:return None
        qs=[v.get('verified_task_success') for v in vals if v.get('verified_task_success') is not None]
        return max(qs) if qs else None

    tol=max(0.01,float(noise or 0.0))

    # E8 transfer: KEEP is impossible with only one target. A target counts only after a complete
    # A0_BARE vs frozen-winner holdout matrix at the frozen repetition count. If E7 itself selected
    # a control A0_* arm, there is no external policy to transfer and E8 must not manufacture one.
    no_external_policy=bool(e7 and str(e7).startswith('A0_'))
    e8_live=[r for r in live_completed if r.get('experiment_id')=='E8_TRANSFER' and r.get('split')=='holdout']
    e8_by_target=defaultdict(list)
    for r in e8_live:e8_by_target[_target_id(r)].append(r)
    e8_tasks=manifest['experiment_tasks']['E8_TRANSFER']['holdout']
    e8_required_arms=[] if no_external_policy else (['A0_BARE',e7] if e7 else ['A0_BARE'])
    e8_target_results={}
    complete_targets=[]
    for tid,trs in sorted(e8_by_target.items()):
        present={(r.get('arm_id'),r.get('task_id'),int(r.get('repeat',0))) for r in trs}
        expected={(aid,task,rep) for aid in e8_required_arms for task in e8_tasks for rep in range(min_reps)}
        missing=expected-present
        complete=(not no_external_policy) and not missing and len(set(e8_required_arms))==2
        def aq(aid):
            obj=[r['offline_score']['score'] for r in trs if r.get('arm_id')==aid and (r.get('offline_score') or {}).get('verification_strength')=='objective']
            return _mean(obj)
        base=aq('A0_BARE'); frozen=aq(e7) if e7 else None
        delta=None if base is None or frozen is None else frozen-base
        e8_target_results[tid]={'complete':complete,'missing_trial_count':len(missing),'baseline_quality':base,'frozen_quality':frozen,'delta':delta,'backend_model':trs[0].get('backend_model'),'transfer_target_tag':trs[0].get('transfer_target_tag')}
        if complete: complete_targets.append(tid)
    if no_external_policy:
        e8_status='NO_EXTERNAL_POLICY_SURVIVED_DEV'
    elif not has_live_attempts:
        e8_status='PENDING_USER_LOCAL_RUN'
    elif not live_completed:
        e8_status='LIVE_RUN_INCOMPLETE_OR_FAILED'
    elif not e8_live:
        e8_status='PENDING_E8_LOCAL_RUN'
    elif not complete_targets:
        e8_status='INCOMPLETE_TRANSFER_RUN'
    elif len(complete_targets)<2:
        e8_status='PENDING_SECOND_LOCAL_TARGET'
    else:
        e8_status='TWO_TARGET_RESULTS_PRESENT_REVIEW_REQUIRED'

    frozen_policy_class='DROP' if no_external_policy else 'INCONCLUSIVE'
    deltas=[e8_target_results[t]['delta'] for t in complete_targets if e8_target_results[t]['delta'] is not None]
    if (not no_external_policy) and len(complete_targets)==1 and deltas:
        if deltas[0]>tol: frozen_policy_class='MODEL_CONDITIONED'
        elif deltas[0]<-tol: frozen_policy_class='DROP'
    elif (not no_external_policy) and len(complete_targets)>=2 and len(deltas)>=2:
        if all(d>tol for d in deltas): frozen_policy_class='KEEP'
        elif all(d<-tol for d in deltas): frozen_policy_class='DROP'
        elif any(d>tol for d in deltas): frozen_policy_class='MODEL_CONDITIONED'
        else: frozen_policy_class='INCONCLUSIVE'

    comparison_map={
      'adaptive_breadth':('E2_COMPUTE_CONTROL','A2_ADAPTIVE_BREADTH','A0_MATCHED3'),
      'structured_depth_proxy':('E2_COMPUTE_CONTROL','A2_STRUCTURED_DEPTH','A1_FIXED_HIGH'),
      'same_context_self_critique':('E3_VERIFICATION_TRUST','A3_SELF_CRITIQUE','A0_RETRY2'),
      'fresh_independent_judge':('E3_VERIFICATION_TRUST','A4_FRESH_JUDGE','A0_RETRY2'),
      'objective_hybrid_verification':('E3_VERIFICATION_TRUST','A4_OBJECTIVE_HYBRID','A0_RETRY2'),
      'best_so_far_repair':('E3_VERIFICATION_TRUST','A4_BEST_SO_FAR','A0_MATCHED3'),
      'detailed_upfront_plan':('E4_PLANNING_AND_SCAFFOLD_GATE','A5_DETAILED_PLAN','A0_RETRY2'),
      'specification_first':('E4_PLANNING_AND_SCAFFOLD_GATE','A5_SPEC_FIRST','A0_RETRY2'),
      'gated_decomposition':('E4_PLANNING_AND_SCAFFOLD_GATE','A5_GATED_DECOMPOSE','A0_MATCHED4'),
      'independent_branches':('E5_BRANCH_AND_ADVISOR','A6_INDEPENDENT_N4','A0_MATCHED5'),
      'debate':('E5_BRANCH_AND_ADVISOR','A7_DEBATE_N2','A0_MATCHED5'),
      'advisor_early':('E5_BRANCH_AND_ADVISOR','A8_ADVISOR_EARLY','A0_MATCHED3'),
      'advisor_orientation':('E5_BRANCH_AND_ADVISOR','A8_ADVISOR_ORIENTATION','A0_MATCHED3'),
      'advisor_failure':('E5_BRANCH_AND_ADVISOR','A8_ADVISOR_FAILURE','A0_MATCHED3'),
      'linear_completion_loop':('E6_LONG_LOOP_COMPLETION','A9_LINEAR_LOOP','A0_MATCHED3'),
      'dynamic_completion_loop':('E6_LONG_LOOP_COMPLETION','A9_DYNAMIC_LONG_LOOP','A0_MATCHED4'),
      'minimal_core':('E7_CORE_SIMPLIFICATION','A10_MINIMAL_CORE','A0_MATCHED3'),
      'five_core':('E7_CORE_SIMPLIFICATION','A10_FIVE_CORE','A0_MATCHED4'),
      'full_gated':('E7_CORE_SIMPLIFICATION','A10_FULL_GATED','A0_MATCHED5')
    }
    tactic_decisions={}
    for name,(eid,aid,bid) in comparison_map.items():
        if not live_completed:
            reason='LIVE_ATTEMPTS_NO_COMPLETED_RESULTS' if has_live_attempts else 'PENDING_USER_LOCAL_RUN'
            tactic_decisions[name]={'classification':'INCONCLUSIVE','reason':reason}; continue
        aq=group_value(eid,aid,'holdout',require_complete=True); bq=group_value(eid,bid,'holdout',require_complete=True); source='holdout'
        if aq is None or bq is None:
            aq=group_value(eid,aid,'dev'); bq=group_value(eid,bid,'dev'); source='dev_only'
        if aq is None or bq is None:
            cls='INCONCLUSIVE'; reason='missing or incomplete comparison'
        elif aq>bq+tol:
            cls='KEEP' if source=='holdout' else 'INCONCLUSIVE'; reason=f'{source} quality delta {aq-bq:+.4f} above tolerance {tol:.4f}'
        elif aq<bq-tol:
            cls='DROP'; reason=f'{source} quality delta {aq-bq:+.4f} below matched simpler baseline'
        else:
            cls='INCONCLUSIVE'; reason=f'difference within noise/tolerance ({aq-bq:+.4f}, tol={tol:.4f})'
        tactic_decisions[name]={'classification':cls,'reason':reason,'arm':aid,'baseline':bid,'source':source,'arm_quality':aq,'baseline_quality':bq}

    controller_tactics={
      'TASK_EVIDENCE_STATE_MONITOR':['specification_first','gated_decomposition','dynamic_completion_loop'],
      'COMPUTE_CONTROLLER':['adaptive_breadth','structured_depth_proxy'],
      'SCAFFOLD_ACTION_GATE':['gated_decomposition','independent_branches','debate','advisor_orientation','advisor_failure'],
      'VERIFICATION_TRUST_CONTROLLER':['fresh_independent_judge','objective_hybrid_verification','best_so_far_repair'],
      'COMPLETION_STOP_CONTROLLER':['best_so_far_repair','dynamic_completion_loop']
    }
    controller_decisions={}
    for c,names in controller_tactics.items():
        classes=[tactic_decisions[n]['classification'] for n in names]
        if 'KEEP' in classes: cls='KEEP'
        elif all(x=='DROP' for x in classes): cls='DROP'
        else: cls='INCONCLUSIVE'
        controller_decisions[c]={'classification':cls,'evidence_tactics':names}

    decision_table={'controllers':controller_decisions,'tactics':tactic_decisions,'frozen_policy':{'classification':frozen_policy_class,'arm':e7,'transfer_status':e8_status},'interpretation':'KEEP requires complete holdout evidence and, for the frozen whole policy, at least two complete distinct target identities. One target is MODEL_CONDITIONED at most.'}

    if has_live_attempts and not live_completed: status='LIVE_ATTEMPTS_NO_COMPLETED_RESULTS'
    elif live_completed: status='LIVE_RESULTS_PRESENT_REVIEW_REQUIRED'
    else: status='MOCK_ONLY_NO_EMPIRICAL_CLAIM'
    out={
      'generated_utc':now_utc(),'run_id':run_id,'status':status,
      'live_trial_count':len(live_completed),'live_attempt_count':len(live_attempts),'live_failed_attempt_count':sum(1 for r in live_attempts if r.get('status')=='FAILED'),
      'mock_trial_count':len([r for r in completed_all if r.get('mock_only')]),
      'primary_dev_config_hash':primary_hash,'noise_envelope_max_score_std':noise,'e0_task_score_std':task_stds,
      'groups':summary,'selected_dev_arms':selected,'e7_winner':e7,
      'e8_transfer_status':e8_status,'e8_complete_target_count':len(complete_targets),'e8_target_results':e8_target_results,
      'decision_table':decision_table,
      'decision_warning':'Selections are dev-only until frozen. FAILED attempts never count as quality successes but remain in reliability/resource accounting. KEEP is scoped to complete tested holdout and never implies Fable-private provenance or untested model-agnostic transfer.'
    }
    dump_json(rdir/'analysis.json',out)
    lines=['# Analysis — '+run_id,'',f"Status: **{status}**",f"Live completed trials: {len(live_completed)}; live attempts: {len(live_attempts)}; failed live attempts: {out['live_failed_attempt_count']}",f"E0 noise envelope (max score std): {noise}",f"E8 transfer status: **{e8_status}**",f"Complete E8 targets: **{len(complete_targets)}**",'','## Dev-selected arms']
    for k,v in selected.items(): lines.append(f'- {k}: `{v}`')
    lines += ['','## Controller decision table']
    for c,v in decision_table['controllers'].items(): lines.append(f"- {c}: **{v['classification']}**")
    lines += ['',f"Frozen policy: **{decision_table['frozen_policy']['classification']}** ({e7})",'', 'KEEP for the frozen whole policy requires at least two complete distinct E8 targets. Mock results are never empirical evidence.']
    (rdir/'analysis.md').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    return out


def freeze_policy(run_id, config_path, allow_mock=False):
    root=package_root(); rdir=root/'RUNS'/run_id; rp=rdir/'results.jsonl'
    if not rp.exists(): raise FileNotFoundError(rp)
    rows=load_results(rp); cfg=load_json(config_path)
    cfg_hash=runtime_config_hash(cfg); study_hash=study_definition_hash(root)
    repetitions=max(5,int(cfg.get('experiment',{}).get('minimum_repetitions',5)))
    required=required_dev_slots(root,cfg_hash,repetitions)

    holdout_rows=[r for r in rows if r.get('split')=='holdout']
    snap_path=rdir/'POLICY_SNAPSHOT.json'
    if snap_path.exists():
        snap=load_json(snap_path)
        if holdout_rows:
            raise RuntimeError('Policy is already frozen and holdout data exists; re-freeze is forbidden. Use a new run-id.')
        current_digest=dev_results_digest(rows,set(snap.get('required_dev_slots') or []))
        if snap.get('config_hash')==cfg_hash and snap.get('study_definition_hash')==study_hash and snap.get('dev_results_digest')==current_digest:
            return snap
        raise RuntimeError('Existing POLICY_SNAPSHOT does not match current config/study/dev results; use a new run-id')
    if holdout_rows:
        raise RuntimeError('Cannot freeze after holdout attempts already exist; use a clean run-id')

    dev_rows=[r for r in rows if r.get('split')=='dev']
    if not dev_rows: raise RuntimeError('Cannot freeze: no dev trials exist')
    bad_cfg=sorted({r.get('config_hash') for r in dev_rows if r.get('config_hash')!=cfg_hash})
    if bad_cfg: raise RuntimeError(f'Cannot freeze: dev results contain different runtime config hashes: {bad_cfg[:3]}')
    bad_study=[r for r in dev_rows if r.get('study_definition_hash')!=study_hash]
    if bad_study: raise RuntimeError('Cannot freeze: dev results were produced by a different or untracked study definition')

    completed=completed_by_slot(dev_rows)
    missing=sorted(required-set(completed))
    if missing:
        unresolved_failed=sum(1 for r in dev_rows if r.get('status')=='FAILED' and record_slot_key(r) in set(missing))
        raise RuntimeError(f'Cannot freeze: {len(missing)} required dev trial slots are incomplete (failed attempts among them: {unresolved_failed}). First missing: {missing[:5]}')

    required_records=[completed[k] for k in sorted(required)]
    for rec in required_records: validate_trial_record_integrity(root,rec)
    mock_flags={bool(r.get('mock_only')) for r in required_records}
    if len(mock_flags)>1: raise RuntimeError('Cannot freeze: required dev matrix mixes mock and live trials')
    if mock_flags=={True} and not allow_mock:
        raise RuntimeError('Cannot freeze empirical policy from mock-only results. For harness self-tests only, pass --allow-mock.')

    a=analyze(run_id)
    manifest=load_json(root/'04_TASK_SUITE_MANIFEST.yaml')
    expected_selection=[eid for eid,v in manifest['experiment_tasks'].items() if v.get('dev')]
    missing_selected=[eid for eid in expected_selection if not a.get('selected_dev_arms',{}).get(eid)]
    if missing_selected: raise RuntimeError(f'Cannot freeze: dev winner missing for {missing_selected}')
    if not a.get('e7_winner'): raise RuntimeError('Cannot freeze: E7 dev winner is missing')

    digest=dev_results_digest(rows,required)
    snap={
      'schema_version':'2.0','frozen_utc':now_utc(),'run_id':run_id,
      'config_hash':cfg_hash,'config_file_sha256':file_sha256(config_path),
      'study_definition_hash':study_hash,'dev_results_digest':digest,
      'minimum_repetitions':repetitions,'required_dev_slot_count':len(required),'required_dev_slots':sorted(required),
      'policy':cfg.get('policy',{}),'sampling':cfg.get('sampling',{}),'feature_mode':cfg.get('experiment',{}).get('feature_mode'),
      'selected_arms':a.get('selected_dev_arms',{}),'e7_winner':a.get('e7_winner'),
      'mock_only':mock_flags=={True},'holdout_locked_to_this_snapshot':True,
      'note':'Mock-derived snapshot is self-test only; no empirical claim.' if mock_flags=={True} else 'Frozen only after complete live dev matrix; holdout config/study/dev digest are integrity-locked.'
    }
    dump_json(snap_path,snap); return snap
