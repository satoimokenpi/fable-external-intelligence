from __future__ import annotations

import json
from pathlib import Path
from typing import Iterable

from .utils import canonical_hash, file_sha256, load_json


def study_definition_files(root: Path) -> list[Path]:
    root = Path(root)
    fixed = [
        root / '03_EXPERIMENT_ARMS.yaml',
        root / '04_TASK_SUITE_MANIFEST.yaml',
        root / '06_MATCHED_COMPUTE_RULES.yaml',
        root / '07_TRIGGER_AND_ABLATION_MATRIX.yaml',
        root / '09_RESULTS_SCHEMA.json',
        root / '10_DECISION_GATE.yaml',
    ]
    harness = sorted(p for p in (root / 'HARNESS').glob('*.py') if p.is_file())
    tasks = sorted(p for p in (root / 'TASKS').glob('*/*.json') if p.is_file())
    return [p for p in fixed + harness + tasks if p.exists()]


def study_definition_hash(root: Path) -> str:
    root = Path(root)
    manifest = {
        str(p.relative_to(root)).replace('\\', '/'): file_sha256(p)
        for p in study_definition_files(root)
    }
    return canonical_hash(manifest)


def runtime_config_hash(config: dict) -> str:
    return canonical_hash(config)


def target_identity_payload(config: dict) -> dict:
    backend = config.get('backend', {})
    meta = config.get('model_metadata', {})
    return {
        'backend_type': backend.get('type'),
        'backend_model': backend.get('model'),
        'model_id': meta.get('model_id'),
        'quantization': meta.get('quantization'),
        'context_limit': meta.get('context_limit'),
        'runtime': meta.get('runtime'),
        'prompt_template_version': meta.get('prompt_template_version'),
    }


def target_identity_hash(config: dict) -> str:
    return canonical_hash(target_identity_payload(config))


def trial_slot_key(experiment_id: str, arm_id: str, task_id: str, split: str, repeat: int, config_hash: str) -> str:
    return f'{experiment_id}|{arm_id}|{task_id}|{split}|{int(repeat)}|{config_hash[:12]}'


def record_slot_key(record: dict) -> str:
    if record.get('trial_slot_key'):
        return str(record['trial_slot_key'])
    key = str(record.get('trial_key', ''))
    if '|attempt=' in key:
        return key.rsplit('|attempt=', 1)[0]
    return key


def record_attempt(record: dict) -> int:
    if record.get('attempt') is not None:
        try:
            return int(record['attempt'])
        except Exception:
            return 0
    key = str(record.get('trial_key', ''))
    if '|attempt=' in key:
        try:
            return int(key.rsplit('|attempt=', 1)[1])
        except Exception:
            return 0
    return 0


def load_results(path: Path) -> list[dict]:
    path = Path(path)
    if not path.exists():
        return []
    rows = []
    for line_no, line in enumerate(path.read_text(encoding='utf-8').splitlines(), 1):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except Exception as exc:
            raise ValueError(f'Invalid JSONL at {path}:{line_no}: {exc}') from exc
    return rows


def completed_by_slot(rows: Iterable[dict]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for r in rows:
        if r.get('status') != 'COMPLETED':
            continue
        slot = record_slot_key(r)
        prev = out.get(slot)
        if prev is None or record_attempt(r) >= record_attempt(prev):
            out[slot] = r
    return out


def dev_results_digest(rows: Iterable[dict], required_slots: set[str] | None = None) -> str:
    completed = completed_by_slot(rows)
    if required_slots is not None:
        completed = {k: v for k, v in completed.items() if k in required_slots}
    payload = []
    for slot in sorted(completed):
        r = completed[slot]
        payload.append({
            'trial_slot_key': slot,
            'trial_key': r.get('trial_key'),
            'experiment_id': r.get('experiment_id'),
            'arm_id': r.get('arm_id'),
            'task_id': r.get('task_id'),
            'split': r.get('split'),
            'repeat': r.get('repeat'),
            'config_hash': r.get('config_hash'),
            'study_definition_hash': r.get('study_definition_hash'),
            'status': r.get('status'),
            'final_output': r.get('final_output'),
            'offline_score': r.get('offline_score'),
            'resources': r.get('resources'),
            'actions': r.get('actions'),
        })
    return canonical_hash(payload)


def required_dev_slots(root: Path, config_hash: str, repetitions: int) -> set[str]:
    root = Path(root)
    arms = load_json(root / '03_EXPERIMENT_ARMS.yaml')
    manifest = load_json(root / '04_TASK_SUITE_MANIFEST.yaml')
    slots: set[str] = set()
    for eid in arms['experiments']:
        tids = manifest['experiment_tasks'].get(eid, {}).get('dev', [])
        if not tids:
            continue
        for tid in tids:
            for aid in arms['experiments'][eid]['arms']:
                if aid == 'FROZEN_WINNER':
                    continue
                for rep in range(int(repetitions)):
                    slots.add(trial_slot_key(eid, aid, tid, 'dev', rep, config_hash))
    return slots



def validate_trial_record_integrity(root: Path, record: dict) -> None:
    """Recompute structural/scoring/resource invariants for one persisted trial record.

    This is an accidental-corruption / benchmark-integrity check, not a cryptographic trust anchor
    against an adversary who can rewrite every local file.
    """
    root=Path(root).resolve()
    required=('experiment_id','arm_id','task_id','split','repeat','config_hash','trial_slot_key','trial_key','status','resources','offline_score','raw_path')
    missing=[k for k in required if k not in record]
    if missing:
        raise RuntimeError(f"Trial record missing required fields: {missing}")
    slot=trial_slot_key(record['experiment_id'],record['arm_id'],record['task_id'],record['split'],int(record['repeat']),record['config_hash'])
    if record_slot_key(record)!=slot or record.get('trial_slot_key')!=slot:
        raise RuntimeError(f"Trial slot key mismatch for {record.get('trial_key')}")
    expected_key=f"{slot}|attempt={record_attempt(record)}"
    if record.get('trial_key')!=expected_key:
        raise RuntimeError(f"Trial attempt key mismatch: expected {expected_key}")

    # Re-score COMPLETED outputs from the task definition/variant rather than trusting persisted score fields.
    if record.get('status')=='COMPLETED':
        from .task_loader import load_task
        from .scoring import offline_score
        variant_seed=(record.get('variant') or {}).get('seed')
        task=load_task(record['task_id'],record['split'],variant_seed=variant_seed)
        calc=offline_score(task,record.get('final_output',''))
        stored=record.get('offline_score') or {}
        for k in ('score','content_score','passed','verification_strength','completion_rate'):
            if stored.get(k)!=calc.get(k):
                raise RuntimeError(f"Stored offline score mismatch for {record.get('trial_key')}: field {k}")
    elif record.get('status')=='FAILED':
        if not record.get('failure'):
            raise RuntimeError(f"FAILED trial missing failure metadata: {record.get('trial_key')}")
    else:
        raise RuntimeError(f"Unknown trial status {record.get('status')!r}")

    # Results JSONL and raw call-record file must agree.
    rel=Path(str(record['raw_path']))
    raw_path=(root/rel).resolve()
    if not raw_path.is_relative_to(root):
        raise RuntimeError('raw_path escapes package root')
    if not raw_path.exists():
        raise RuntimeError(f"Missing raw trial file: {rel}")
    raw=load_json(raw_path)
    for k in ('trial_key','trial_slot_key','attempt','status','final_output','offline_score','resources','config_hash','study_definition_hash','target_identity_hash'):
        if raw.get(k)!=record.get(k):
            raise RuntimeError(f"Raw/results mismatch for {record.get('trial_key')}: field {k}")
    calls=raw.get('call_records')
    if not isinstance(calls,list):
        raise RuntimeError(f"Raw trial missing call_records list: {record.get('trial_key')}")
    resources=record.get('resources') or {}
    if int(resources.get('inference_call_attempts',resources.get('inference_calls',0)) or 0)!=len(calls):
        raise RuntimeError(f"Inference-call accounting mismatch for {record.get('trial_key')}")
    successes=sum(1 for c in calls if c.get('ok'))
    failures=sum(1 for c in calls if c.get('status')=='FAILED')
    if int(resources.get('successful_inference_calls',successes) or 0)!=successes:
        raise RuntimeError(f"Successful-call accounting mismatch for {record.get('trial_key')}")
    if int(resources.get('failed_inference_calls',failures) or 0)!=failures:
        raise RuntimeError(f"Failed-call accounting mismatch for {record.get('trial_key')}")
    attempted=sum(int(c.get('attempted_max_output_tokens') or 0) for c in calls)
    if int(resources.get('attempted_output_token_cap') or 0)!=attempted:
        raise RuntimeError(f"Attempted-output-cap accounting mismatch for {record.get('trial_key')}")
    est_in=sum(int(c.get('estimated_input_tokens') or 0) for c in calls)
    stored_est=resources.get('estimated_input_tokens')
    if (stored_est if stored_est is not None else 0)!=est_in:
        raise RuntimeError(f"Estimated-input accounting mismatch for {record.get('trial_key')}")
    rep_in=sum(int((c.get('usage') or {}).get('prompt_tokens') or 0) for c in calls)
    rep_out=sum(int((c.get('usage') or {}).get('completion_tokens') or 0) for c in calls)
    if (resources.get('reported_input_tokens') or 0)!=rep_in or (resources.get('reported_output_tokens') or 0)!=rep_out:
        raise RuntimeError(f"Reported-token accounting mismatch for {record.get('trial_key')}")

def snapshot_runtime_contract(config: dict) -> dict:
    return {
        'policy': config.get('policy', {}),
        'sampling': config.get('sampling', {}),
        'feature_mode': config.get('experiment', {}).get('feature_mode'),
    }


def validate_snapshot_runtime_contract(snapshot: dict, config: dict, *, allow_model_change: bool) -> None:
    contract = snapshot_runtime_contract(config)
    if contract.get('policy') != snapshot.get('policy'):
        raise RuntimeError('Frozen policy mismatch: runtime policy changed after freeze')
    if contract.get('sampling') != snapshot.get('sampling'):
        raise RuntimeError('Frozen sampling mismatch: sampling changed after freeze')
    if contract.get('feature_mode') != snapshot.get('feature_mode'):
        raise RuntimeError('Frozen feature_mode mismatch after freeze')
    if not allow_model_change:
        ch = runtime_config_hash(config)
        if ch != snapshot.get('config_hash'):
            raise RuntimeError('Frozen runtime config mismatch: holdout must use the exact frozen config')
