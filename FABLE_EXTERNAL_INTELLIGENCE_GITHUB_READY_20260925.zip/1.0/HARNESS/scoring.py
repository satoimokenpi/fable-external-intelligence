from __future__ import annotations
import ast, json, math, re


def _norm(s): return re.sub(r'\s+',' ',str(s).strip()).casefold()

def _json(text):
    try: return json.loads(text)
    except Exception:
        m=re.search(r'\{.*\}', text, re.S)
        if m:
            try:return json.loads(m.group(0))
            except Exception:return None
        return None


def offline_score(task, output):
    spec=task['private_evaluation']; typ=spec['type']; base_score=0.0; details={}; strength='objective'
    if typ=='exact':
        base_score=1.0 if _norm(output)==_norm(spec['expected']) else 0.0
    elif typ=='json_exact':
        obj=_json(output); base_score=1.0 if obj==spec['expected'] else 0.0; details['parsed']=obj
    elif typ=='json_subset':
        obj=_json(output); exp=spec['expected']; ok=isinstance(obj,dict)
        hits=0
        if ok:
            for k,v in exp.items(): hits += 1 if obj.get(k)==v else 0
        base_score=hits/max(1,len(exp)); details['parsed']=obj; details['expected_field_accuracy']=base_score
    elif typ=='evidence_fields':
        obj=_json(output); fields=spec['fields']; hits=0; citation_hits=0
        if isinstance(obj,dict):
            for k,rule in fields.items():
                val=str(obj.get(k,''))
                if rule['contains'].casefold() in val.casefold(): hits+=1
                if f"[{rule['citation']}]" in val: citation_hits+=1
        base_score=(hits+citation_hits)/(2*max(1,len(fields))); details['evidence_support_rate']=hits/max(1,len(fields)); details['citation_accuracy']=citation_hits/max(1,len(fields)); details['parsed']=obj
    elif typ=='rubric_proxy':
        strength='rubric_proxy'; concepts=spec['required_concepts']; hits=sum(1 for x in concepts if x.casefold() in output.casefold()); base_score=hits/max(1,len(concepts)); details['rubric_hits']=hits
    else: raise ValueError(f'Unknown evaluator {typ}')
    completion=completion_score(task,output)
    # A response cannot count as fully successful when required obligations are missing,
    # even if every field in a narrower expected subset is correct.
    score=min(float(base_score), float(completion))
    passed=bool(base_score>=0.999 and completion>=0.999)
    return {'score':score,'content_score':float(base_score),'passed':passed,'verification_strength':strength,'completion_rate':completion,**details}


def completion_score(task, output):
    obligations=task.get('obligations') or []
    if not obligations:return 1.0
    obj=_json(output)
    if isinstance(obj,dict): return sum(1 for x in obligations if x in obj and obj[x] not in (None,''))/len(obligations)
    low=output.casefold(); return sum(1 for x in obligations if x.casefold() in low)/len(obligations)


_ALLOWED_AST=(ast.Expression,ast.Constant,ast.BinOp,ast.UnaryOp,ast.Add,ast.Sub,ast.Mult,ast.Div,ast.FloorDiv,ast.Mod,ast.Pow,ast.USub,ast.UAdd,ast.Load)
def _safe_eval(expr):
    tree=ast.parse(expr,mode='eval')
    for node in ast.walk(tree):
        if not isinstance(node,_ALLOWED_AST): raise ValueError('unsafe expression')
    return eval(compile(tree,'<validator>','eval'),{'__builtins__':{}},{})


def online_validate(task, output):
    spec=task.get('online_validator')
    if not spec:return {'available':False,'passed':None,'score':None,'source':'none'}
    typ=spec['type']; passed=False; score=0.0; detail={}
    if typ=='numeric_expression':
        expected=float(_safe_eval(spec['expression']));
        m=re.search(r'-?\d+(?:\.\d+)?', output)
        if m:
            got=float(m.group(0)); passed=abs(got-expected)<=float(spec.get('tolerance',0)); detail={'expected':expected,'got':got}
        score=1.0 if passed else 0.0
    elif typ=='choice':
        got=output.strip().upper()[:1]; passed=got==str(spec['correct']).upper(); score=1.0 if passed else 0.0; detail={'got':got}
    elif typ=='json_schema':
        obj=_json(output); keys=spec['required_keys']; present=[k for k in keys if isinstance(obj,dict) and k in obj and obj[k] not in (None,'')]
        passed=isinstance(obj,dict) and len(present)==len(keys); score=len(present)/max(1,len(keys)); detail={'parsed':obj}
    elif typ=='json_field_exact':
        obj=_json(output); got=obj.get(spec['field']) if isinstance(obj,dict) else None; passed=got==spec['expected']; score=1.0 if passed else 0.0; detail={'got':got}
    else: raise ValueError(f'Unknown online validator {typ}')
    return {'available':True,'passed':bool(passed),'score':float(score),'source':typ,**detail}


def parse_judge(text):
    obj={}
    try:
        obj=json.loads(text)
    except Exception:
        m=re.search(r'\{.*\}',text,re.S)
        if m:
            try: obj=json.loads(m.group(0))
            except Exception: obj={}
    verdict=str(obj.get('verdict','')).upper()
    try:
        score=float(obj.get('score')) if obj.get('score') is not None else (1.0 if verdict=='PASS' else 0.0)
    except Exception:
        score=0.0
    score=max(0.0,min(1.0,score))
    if verdict not in {'PASS','FAIL'}:
        verdict='PASS' if score>=.5 else 'FAIL'
    return {'verdict':verdict,'score':score,'reason':str(obj.get('reason','')),'parse_valid':bool(obj)}
