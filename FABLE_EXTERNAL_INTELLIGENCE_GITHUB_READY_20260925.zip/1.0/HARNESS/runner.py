from __future__ import annotations
import json, time
from .backend import OpenAICompatibleBackend, MockBackend
from .controllers import monitor, gate, trigger_metrics, system_prompt
from .scoring import offline_score, online_validate, parse_judge, completion_score
from .task_loader import generation_messages, load_manifest, load_task, package_root
from .utils import canonical_hash, dump_json, estimate_tokens, load_json, now_utc
from .integrity import (study_definition_hash, target_identity_hash, trial_slot_key, record_slot_key, record_attempt, load_results, completed_by_slot, dev_results_digest, required_dev_slots, validate_snapshot_runtime_contract, validate_trial_record_integrity)

TRIGGER_KEYS=('depth_high','breadth_expand','decompose','branch','advisor','verify','long_loop')

class ModelCallFailed(RuntimeError):
    def __init__(self, call_record):
        self.call_record=call_record
        super().__init__(call_record.get('error','model call failed'))


class Budget:
    def __init__(self,spec):
        self.max_calls=int(spec['max_calls'])
        self.max_tokens_total=int(spec['max_tokens_total'])
        self.per_call=int(spec['per_call'])
        self.calls=0
        self.token_caps=0
    def allowance(self):
        if self.calls>=self.max_calls:return 0
        return max(0,min(self.per_call,self.max_tokens_total-self.token_caps))
    def consume(self,cap):
        self.calls+=1; self.token_caps+=int(cap)

class TrialRunner:
    def __init__(self, config, backend, run_id):
        self.config=config; self.backend=backend; self.run_id=run_id
        self.root=package_root(); self.run_dir=self.root/'RUNS'/run_id; self.run_dir.mkdir(parents=True,exist_ok=True)
        self.arms=load_json(self.root/'03_EXPERIMENT_ARMS.yaml')
        self.arm_by_id={x['id']:x for x in self.arms['arms']}
        self.manifest=load_manifest(); self.config_hash=canonical_hash(config)
        self.study_hash=study_definition_hash(self.root)
        self.target_hash=target_identity_hash(config)
        self._active_calls=[]; self._active_budget=None; self._active_features={}; self._active_gate={}; self._active_actions={}; self._active_events=[]

    def _call(self, task, budget, label, messages, seed, candidate=None, max_tokens=None):
        cap=budget.allowance() if max_tokens is None else min(budget.allowance(),int(max_tokens))
        if cap<=0:return None
        budget.consume(cap)
        s=self.config.get('sampling',{})
        base={
            'label':label,'seed':seed,'attempted_max_output_tokens':int(cap),
            'estimated_input_tokens':estimate_tokens(json.dumps(messages,ensure_ascii=False)),
            'status':'ATTEMPTED','ok':False,'usage':{},'text':'','raw':None,
        }
        t=time.perf_counter()
        try:
            r=self.backend.generate(
                messages,max_tokens=cap,temperature=float(s.get('temperature',.2)),top_p=float(s.get('top_p',1.0)),seed=seed,
                meta={'task':task,'label':label,'candidate':candidate or ''})
            rec={**base,**r,'status':'COMPLETED','ok':True}
            rec['elapsed_seconds']=float(r.get('elapsed_seconds') or (time.perf_counter()-t))
            self._active_calls.append(rec)
            return rec
        except Exception as exc:
            rec={**base,'status':'FAILED','ok':False,'elapsed_seconds':time.perf_counter()-t,
                 'error_type':type(exc).__name__,'error':str(exc)[:2000],
                 'billed_usage_unknown':True}
            self._active_calls.append(rec)
            raise ModelCallFailed(rec) from exc

    def _judge(self,task,budget,candidate,seed,label='judge'):
        extra=(
          'Evaluate the candidate against the user request and PUBLIC acceptance criteria only. '
          'Return strict JSON: {"verdict":"PASS|FAIL","score":0.0-1.0,"reason":"brief"}. Candidate:\n'+candidate)
        r=self._call(task,budget,label,generation_messages(task,system_text='Act as a fresh independent criterion judge. Do not assume fluent wording implies correctness.',extra_user=extra),seed,candidate=candidate)
        return parse_judge(r['text']) if r else {'verdict':'NO_BUDGET','score':0.0,'reason':'budget exhausted'}

    def _solve(self,task,budget,seed,label='solve',depth=False,extra=None):
        return self._call(task,budget,label,generation_messages(task,system_text=system_prompt(depth),extra_user=extra),seed)

    def _select(self,task,budget,candidates,seed,events):
        """Select using an intentionally available online validator, else one fresh comparison call.
        Hidden offline ground truth is never used for selection.
        """
        vals=[online_validate(task,c) for c in candidates]
        if any(v['available'] for v in vals):
            idx=max(range(len(candidates)),key=lambda i:(vals[i]['score'] if vals[i]['score'] is not None else -1))
            events.append({'kind':'selector','source':'online_validator','scores':[v.get('score') for v in vals],'selected':idx})
            return candidates[idx]
        if budget.allowance()>0:
            block='\n\n'.join(f'CANDIDATE {i}:\n{c}' for i,c in enumerate(candidates))
            extra=(
              f'Compare {len(candidates)} candidates against the user request and PUBLIC acceptance criteria. '
              f'Return strict JSON only: {{"selected":0,"score":0.0,"reason":"brief"}}, where selected is 0..{len(candidates)-1}.\n\n'+block)
            r=self._call(task,budget,'selector_compare',generation_messages(task,system_text='Act as a fresh independent selector. Prefer correctness and requirement satisfaction over style.',extra_user=extra),seed,candidate=block)
            if r:
                try:
                    obj=json.loads(r['text'])
                    idx=int(obj.get('selected',0)); idx=max(0,min(len(candidates)-1,idx))
                    score=float(obj.get('score',0.0))
                except Exception:
                    idx=0; score=0.0
                events.append({'kind':'selector','source':'fresh_comparison_judge','score':score,'selected':idx})
                return candidates[idx]
        events.append({'kind':'selector','source':'fallback_first','selected':0})
        return candidates[0]

    def execute_strategy(self,task,arm,repeat):
        strategy=arm['strategy']; budget=Budget(arm['budget'])
        seed=int(self.config.get('sampling',{}).get('seed_base',0))+repeat*1000+sum(map(ord,task['id']+arm['id']))
        features=monitor(task,self.config)
        gate_rec=gate(features,self.config)
        actions={k:False for k in TRIGGER_KEYS}
        events=[]; calls=[]
        self._active_calls=calls; self._active_budget=budget; self._active_features=features; self._active_gate=gate_rec; self._active_actions=actions; self._active_events=events
        def keep(r):
            return r['text'] if r else ''
        final=''

        if strategy=='bare':
            final=keep(self._solve(task,budget,seed,'solve',False))

        elif strategy=='fixed_high':
            actions['depth_high']=True
            final=keep(self._solve(task,budget,seed,'solve_fixed_high',True))

        elif strategy=='structured_depth':
            actions['depth_high']=True
            final=keep(self._solve(task,budget,seed,'solve_structured_depth',True,extra='Use the extra allowance on understanding, constraint checking, and difficult decisions rather than drafting the answer twice.'))

        elif strategy=='simple_retry':
            outs=[]
            while budget.allowance()>0:
                outs.append(keep(self._solve(task,budget,seed+len(outs),f'retry_{len(outs)}',False)))
            final=outs[-1] if outs else ''

        elif strategy=='adaptive_breadth':
            actions['depth_high']=gate_rec['depth_high']
            outs=[keep(self._solve(task,budget,seed,'solve',gate_rec['depth_high']))]
            if gate_rec['breadth_expand']:
                actions['breadth_expand']=True
                while budget.allowance()>0 and len(outs)<2:
                    outs.append(keep(self._solve(task,budget,seed+len(outs),f'branch_{len(outs)}',gate_rec['depth_high'])))
            final=self._select(task,budget,outs,seed,events) if len(outs)>1 else outs[0]

        elif strategy=='self_critique':
            first=keep(self._solve(task,budget,seed,'solve',False))
            actions['verify']=True
            msgs=generation_messages(task,system_text='Review the prior answer for concrete errors and return only a corrected final answer.')
            msgs.extend([{'role':'assistant','content':first},{'role':'user','content':'Critique the prior answer against the task, then return only the revised final answer.'}])
            second=keep(self._call(task,budget,'critique_same_context',msgs,seed+1,candidate=first)); final=second or first

        elif strategy in {'fresh_judge','objective_hybrid','best_so_far'}:
            first=keep(self._solve(task,budget,seed,'solve',False)); final=first
            val=online_validate(task,first); judge=None; actions['verify']=True
            if strategy=='fresh_judge' or not val['available']:
                judge=self._judge(task,budget,first,seed+1,'judge_fresh'); events.append({'kind':'verifier','source':'fresh_judge',**judge})
            if val['available']:
                events.append({'kind':'verifier','source':'online_validator','verdict':'PASS' if val['passed'] else 'FAIL','score':val['score']})
            needs_repair=(val['available'] and not val['passed']) or (not val['available'] and judge and judge['verdict']!='PASS')
            if strategy=='best_so_far' and needs_repair and budget.allowance()>0:
                actions['depth_high']=True
                repair=keep(self._solve(task,budget,seed+2,'repair',True,extra='A validator/reviewer found a problem. Repair the candidate while preserving correct content. Prior candidate:\n'+first))
                v0=online_validate(task,first); v1=online_validate(task,repair)
                if v0['available'] and v1['available']:
                    final=repair if v1['score']>v0['score'] else first
                else:
                    # Without objective online feedback, keep old answer unless a fresh judge can compare within budget.
                    final=first
                    if budget.allowance()>0:
                        final=self._select(task,budget,[first,repair],seed+30,events)
                events.append({'kind':'repair','attempted':True,'changed':repair!=first})

        elif strategy in {'detailed_plan','spec_first'}:
            label='plan_detailed' if strategy=='detailed_plan' else 'spec_first'
            plan=keep(self._call(task,budget,label,generation_messages(task,system_text='Extract a working plan/specification. Do not answer the final task yet.'),seed))
            guidance=('Follow this detailed upfront plan:\n' if strategy=='detailed_plan' else 'Freeze obligations/acceptance criteria, but treat implementation path as provisional. Orientation/specification:\n')+plan
            actions['depth_high']=True
            final=keep(self._solve(task,budget,seed+1,'solve_after_plan',True,guidance))

        elif strategy=='gated_decompose':
            if gate_rec['decompose'] and task.get('subtasks'):
                actions['decompose']=True; actions['breadth_expand']=True
                parts=[]
                max_parts=max(1,budget.max_calls-1)
                for i,sub in enumerate(task['subtasks'][:max_parts]):
                    if budget.calls>=budget.max_calls-1 or budget.allowance()<=0: break
                    parts.append(keep(self._solve(task,budget,seed+i,f'branch_{i}',False,extra='Solve only this subtask independently: '+sub)))
                synth='Independent sub-results:\n'+'\n'.join(f'- {x}' for x in parts)
                actions['depth_high']=True
                final=keep(self._solve(task,budget,seed+10,'synthesis',True,extra=synth)) or (parts[-1] if parts else '')
            else:
                actions['depth_high']=gate_rec['depth_high']
                final=keep(self._solve(task,budget,seed,'solve_gate_bypass',gate_rec['depth_high']))

        elif strategy=='independent_branches':
            actions['branch']=True; actions['breadth_expand']=True
            n=int(arm.get('parameters',{}).get('n',2)); outs=[]
            for i in range(n):
                if budget.allowance()<=0: break
                outs.append(keep(self._solve(task,budget,seed+i,f'branch_{i}',False)))
            final=self._select(task,budget,outs,seed+100,events)

        elif strategy=='debate':
            actions['branch']=True; actions['breadth_expand']=True; actions['verify']=True
            outs=[keep(self._solve(task,budget,seed+i,f'branch_{i}',False)) for i in range(2)]
            revised=[]
            for i,c in enumerate(outs):
                other=outs[1-i]
                if budget.allowance()<=0: revised.append(c); continue
                extra=f'Your candidate was:\n{c}\n\nIndependent alternative:\n{other}\n\nCross-check disagreements and return only your revised final answer.'
                revised.append(keep(self._solve(task,budget,seed+10+i,f'critique_{i}',True,extra)))
            final=self._select(task,budget,revised,seed+100,events)

        elif strategy.startswith('advisor_'):
            if strategy=='advisor_early':
                actions['advisor']=True
                adv=keep(self._call(task,budget,'advisor_early',generation_messages(task,system_text='Give strategic advice only; do not solve the task.'),seed))
                orient=keep(self._call(task,budget,'orientation_after_early_advisor',generation_messages(task,system_text='Orient to constraints briefly; do not give final answer.'),seed+1))
                final=keep(self._solve(task,budget,seed+2,'solve_after_advisor',True,extra='Advisor notes:\n'+adv+'\nOrientation:\n'+orient)); actions['depth_high']=True
            elif strategy=='advisor_orientation':
                orient=keep(self._call(task,budget,'orientation',generation_messages(task,system_text='Orient to constraints briefly; do not give final answer.'),seed))
                actions['advisor']=True
                adv=keep(self._call(task,budget,'advisor_after_orientation',generation_messages(task,system_text='Give strategic advice using this orientation; do not solve directly.',extra_user=orient),seed+1))
                final=keep(self._solve(task,budget,seed+2,'solve_after_advisor',True,extra='Orientation:\n'+orient+'\nAdvisor:\n'+adv)); actions['depth_high']=True
            else:
                first=keep(self._solve(task,budget,seed,'solve',False)); val=online_validate(task,first); final=first
                actions['verify']=val['available']
                if val['available'] and not val['passed']:
                    actions['advisor']=True; actions['depth_high']=True
                    adv=keep(self._call(task,budget,'advisor_on_failure',generation_messages(task,system_text='A deterministic check failed. Give repair strategy only.',extra_user='Candidate:\n'+first),seed+1,candidate=first))
                    final=keep(self._solve(task,budget,seed+2,'repair_after_advisor',True,extra='Failed candidate:\n'+first+'\nAdvisor:\n'+adv)) or first

        elif strategy in {'linear_loop','dynamic_long_loop'}:
            first=keep(self._solve(task,budget,seed,'solve',False)); final=first
            if strategy=='linear_loop':
                while budget.allowance()>0:
                    actions['long_loop']=True; actions['depth_high']=True
                    final=keep(self._solve(task,budget,seed+budget.calls,'repair_linear',True,extra='Rewrite the answer once more to ensure all requested items are present. Prior:\n'+final)) or final
            else:
                best=first; bestv=online_validate(task,best); steps=0
                actions['verify']=bestv['available']
                while budget.allowance()>0 and steps<int(self.config.get('policy',{}).get('max_long_loop_steps',3)):
                    comp=completion_score(task,best)
                    if (bestv['available'] and bestv['passed']) and comp>=1.0: break
                    actions['long_loop']=True; actions['depth_high']=True
                    extra='Repair only missing/failed obligations. Preserve correct content and any evidence references. Prior candidate:\n'+best
                    cand=keep(self._solve(task,budget,seed+20+steps,'repair_dynamic',True,extra)); cv=online_validate(task,cand)
                    cand_comp=completion_score(task,cand)
                    old_metric=(bestv['score'] if bestv['available'] and bestv['score'] is not None else 0.0, comp)
                    new_metric=(cv['score'] if cv['available'] and cv['score'] is not None else 0.0, cand_comp)
                    if new_metric>old_metric: best=cand; bestv=cv
                    else: break
                    steps+=1
                final=best

        elif strategy in {'minimal_core','five_core','full_gated'}:
            actions['depth_high']=gate_rec['depth_high']
            first=keep(self._solve(task,budget,seed,'solve',gate_rec['depth_high'])); final=first
            val=online_validate(task,first)
            if strategy in {'five_core','full_gated'} and gate_rec['breadth_expand'] and budget.allowance()>0:
                actions['breadth_expand']=True
                alt=keep(self._solve(task,budget,seed+1,'branch_1',gate_rec['depth_high']))
                final=self._select(task,budget,[first,alt],seed+100,events); val=online_validate(task,final)
            if gate_rec['verify'] and val['available']:
                actions['verify']=True
                if not val['passed'] and budget.allowance()>0:
                    actions['depth_high']=True
                    rep=keep(self._solve(task,budget,seed+2,'repair',True,extra='A deterministic validator failed. Repair the answer while preserving correct parts. Prior:\n'+final)); rv=online_validate(task,rep)
                    final=rep if rv['score']>val['score'] else final
            if strategy=='full_gated' and gate_rec['advisor'] and budget.allowance()>0:
                actions['advisor']=True
                adv=keep(self._call(task,budget,'advisor_optional',generation_messages(task,system_text='Give concise strategic audit only.',extra_user='Candidate:\n'+final),seed+3,candidate=final))
                if budget.allowance()>0:
                    actions['depth_high']=True
                    final=keep(self._solve(task,budget,seed+4,'repair_after_advisor',True,extra='Optional advisor:\n'+adv+'\nPrior:\n'+final)) or final
        else:
            raise ValueError('Unknown strategy '+strategy)

        resources=self._summarize_resources(budget,calls)
        return final,features,gate_rec,actions,events,resources,calls

    def _summarize_resources(self,budget,calls):
        reported_in=sum(int((r.get('usage') or {}).get('prompt_tokens') or 0) for r in calls)
        reported_out=sum(int((r.get('usage') or {}).get('completion_tokens') or 0) for r in calls)
        estimated_in=sum(int(r.get('estimated_input_tokens') or 0) for r in calls)
        estimated_out=sum(estimate_tokens(r.get('text','')) for r in calls if r.get('ok'))
        elapsed=sum(float(r.get('elapsed_seconds') or 0) for r in calls)
        successes=sum(1 for r in calls if r.get('ok'))
        failures=sum(1 for r in calls if r.get('status')=='FAILED')
        usage_complete=all(bool(r.get('usage')) for r in calls if r.get('ok')) and failures==0
        return {
            'inference_calls':len(calls),
            'inference_call_attempts':len(calls),
            'successful_inference_calls':successes,
            'failed_inference_calls':failures,
            'max_output_token_cap_used':budget.token_caps,
            'attempted_output_token_cap':sum(int(r.get('attempted_max_output_tokens') or 0) for r in calls),
            'reported_input_tokens':reported_in or None,
            'reported_output_tokens':reported_out or None,
            'estimated_input_tokens':estimated_in or None,
            'estimated_output_tokens':estimated_out,
            'usage_reporting_complete':usage_complete,
            'tool_calls':0,
            'elapsed_seconds':elapsed,
        }

    def _resolved_frozen_arm(self):
        snap_path=self.run_dir/'POLICY_SNAPSHOT.json'
        if not snap_path.exists(): raise RuntimeError('FROZEN_WINNER requires POLICY_SNAPSHOT.json')
        snap=load_json(snap_path); aid=snap.get('e7_winner')
        if not aid: raise RuntimeError('POLICY_SNAPSHOT has no e7_winner; complete/analyze E7 on dev before holdout/transfer')
        return aid

    def run_trial(self,experiment_id,arm_id,task_id,split,repeat,attempt=0):
        if arm_id=='FROZEN_WINNER': arm_id=self._resolved_frozen_arm()
        arm=self.arm_by_id[arm_id]
        variant_seed=int(self.config.get('sampling',{}).get('seed_base',0))+int(repeat)*100003+sum(map(ord,task_id))
        task=load_task(task_id,split,variant_seed=variant_seed)
        slot=trial_slot_key(experiment_id,arm_id,task_id,split,repeat,self.config_hash)
        key=f'{slot}|attempt={int(attempt)}'
        self._active_calls=[]; self._active_budget=None; self._active_features={}; self._active_gate={}; self._active_actions={}; self._active_events=[]
        failure=None
        try:
            final,features,gate_rec,actions,events,resources,calls=self.execute_strategy(task,arm,repeat)
            status='COMPLETED'
            off=offline_score(task,final)
            tm=trigger_metrics(task,actions); gm=trigger_metrics(task,gate_rec)
        except ModelCallFailed as exc:
            status='FAILED'; final=''
            calls=list(self._active_calls); budget=self._active_budget or Budget(arm['budget'])
            resources=self._summarize_resources(budget,calls)
            features=dict(self._active_features or monitor(task,self.config)); gate_rec=dict(self._active_gate or gate(features,self.config)); actions=dict(self._active_actions or {k:False for k in TRIGGER_KEYS}); events=list(self._active_events or [])
            off={'score':None,'content_score':None,'passed':False,'verification_strength':'not_scored_failure','completion_rate':0.0}
            tm=trigger_metrics(task,actions); gm=trigger_metrics(task,gate_rec)
            failure={'type':exc.call_record.get('error_type'),'message':exc.call_record.get('error'),'call_label':exc.call_record.get('label'),'billed_usage_unknown':bool(exc.call_record.get('billed_usage_unknown'))}
        verifier_events=[e for e in events if e.get('kind')=='verifier']
        false_pass=bool(status=='COMPLETED' and any(e.get('verdict')=='PASS' and not off['passed'] and off['verification_strength']=='objective' for e in verifier_events))
        record={
          'trial_key':key,'trial_slot_key':slot,'attempt':int(attempt),'run_id':self.run_id,'timestamp_utc':now_utc(),'experiment_id':experiment_id,'arm_id':arm_id,'task_id':task_id,'split':split,'repeat':repeat,
          'backend_kind':self.backend.kind,'backend_model':self.config.get('backend',{}).get('model'),'model_metadata':self.config.get('model_metadata',{}),'transfer_target_tag':self.config.get('transfer',{}).get('target_tag'),
          'target_identity_hash':self.target_hash,'study_definition_hash':self.study_hash,
          'status':status,'final_output':final,'offline_score':off,'resources':resources,'features':features,'gate_recommendations':gate_rec,'actions':actions,'trigger_metrics':tm,'gate_prediction_metrics':gm,
          'verifier_events':verifier_events,'false_pass':false_pass,'config_hash':self.config_hash,'mock_only':self.backend.kind=='mock','variant':task.get('_variant'),'failure':failure}
        raw_dir=self.run_dir/'raw'; raw_dir.mkdir(exist_ok=True)
        raw_path=raw_dir/(canonical_hash({'k':key})[:20]+'.json'); record['raw_path']=str(raw_path.relative_to(self.root))
        safe_calls=[]
        for r in calls:
            safe_calls.append({k:v for k,v in r.items() if k not in {'raw'}} | {'raw':r.get('raw')})
        dump_json(raw_path,{**record,'call_records':safe_calls})
        return record

    def _validate_holdout_integrity(self, experiment_id):
        snap_path=self.run_dir/'POLICY_SNAPSHOT.json'
        if not snap_path.exists(): raise RuntimeError('Holdout is locked until freeze-policy creates POLICY_SNAPSHOT.json')
        snap=load_json(snap_path)
        if self.study_hash!=snap.get('study_definition_hash'):
            raise RuntimeError('Study definition changed after freeze; holdout refused')
        validate_snapshot_runtime_contract(snap,self.config,allow_model_change=(experiment_id=='E8_TRANSFER'))
        if bool(snap.get('mock_only')) != (self.backend.kind=='mock'):
            raise RuntimeError('Mock/live boundary mismatch: a frozen mock study cannot be continued as live evidence, and vice versa')
        rows=load_results(self.run_dir/'results.jsonl')
        repetitions=int(snap.get('minimum_repetitions') or 5)
        required=set(snap.get('required_dev_slots') or [])
        expected_required=required_dev_slots(self.root,str(snap.get('config_hash') or ''),repetitions)
        if required!=expected_required:
            raise RuntimeError('Frozen required-dev matrix is inconsistent with the frozen config/study definition')
        completed=completed_by_slot(rows)
        missing=required-set(completed)
        if missing:
            raise RuntimeError(f'Frozen dev matrix is no longer complete; {len(missing)} required slots are missing')
        for slot in required:
            rec=completed[slot]
            validate_trial_record_integrity(self.root,rec)
            if rec.get('config_hash')!=snap.get('config_hash') or rec.get('study_definition_hash')!=snap.get('study_definition_hash'):
                raise RuntimeError('Frozen dev record/config/study mismatch detected')
        if required:
            digest=dev_results_digest(rows,required)
            if digest!=snap.get('dev_results_digest'):
                raise RuntimeError('Frozen dev results changed after freeze; holdout refused')
        # Recompute dev winners from the frozen evidence so editing POLICY_SNAPSHOT cannot silently
        # change the selected policy after seeing holdout.
        from .analyze import analyze
        recomputed=analyze(self.run_id).get('selected_dev_arms',{})
        if recomputed!=snap.get('selected_arms',{}):
            raise RuntimeError('Frozen selected arms do not match recomputed dev winners; snapshot tampering/inconsistency detected')
        if snap.get('e7_winner')!=recomputed.get('E7_CORE_SIMPLIFICATION'):
            raise RuntimeError('Frozen E7 winner does not match recomputed dev evidence')
        return snap

    def run_experiment(self,experiment_id,split='dev',repeats=None):
        exp=self.arms['experiments'][experiment_id]; tids=self.manifest['experiment_tasks'][experiment_id][split]
        if not tids:return {'scheduled':0,'completed':0,'failed':0,'skipped':0}
        repeats=max(5,int(repeats or self.config.get('experiment',{}).get('minimum_repetitions',5)))
        arm_ids=list(exp['arms'])
        snap_path=self.run_dir/'POLICY_SNAPSHOT.json'
        if split=='dev' and snap_path.exists():
            raise RuntimeError('Dev is frozen for this run-id; create a new run-id instead of modifying post-freeze dev data')
        if split=='holdout':
            snap=self._validate_holdout_integrity(experiment_id)
            if experiment_id!='E8_TRANSFER':
                selected=snap.get('selected_arms',{}).get(experiment_id)
                if not selected: raise RuntimeError(f'No frozen dev-selected arm for {experiment_id}')
                baselines=[x for x in arm_ids if x.startswith('A0_') or x=='A0_BARE' or x=='A1_FIXED_HIGH']
                arm_ids=list(dict.fromkeys(baselines+[selected]))
            else:
                frozen=self._resolved_frozen_arm()
                if str(frozen).startswith('A0_'):
                    raise RuntimeError('E8 has no external policy to transfer: E7 selected a control baseline. Treat the external policy as DROP/NO_POLICY and start a new study if you change it.')
        results_path=self.run_dir/'results.jsonl'; rows=load_results(results_path)
        for r in rows:
            if r.get('status')=='COMPLETED':
                validate_trial_record_integrity(self.root,r)
        completed_slots={record_slot_key(r) for r in rows if r.get('status')=='COMPLETED'}
        attempt_counts={}
        for r in rows:
            slot=record_slot_key(r); attempt_counts[slot]=max(attempt_counts.get(slot,0),record_attempt(r)+1)
        completed=failed=skipped=0
        with results_path.open('a',encoding='utf-8') as f:
            for tid in tids:
                for aid in arm_ids:
                    for rep in range(repeats):
                        actual_aid=self._resolved_frozen_arm() if aid=='FROZEN_WINNER' else aid
                        slot=trial_slot_key(experiment_id,actual_aid,tid,split,rep,self.config_hash)
                        if slot in completed_slots: skipped+=1; continue
                        attempt=attempt_counts.get(slot,0)
                        rec=self.run_trial(experiment_id,aid,tid,split,rep,attempt=attempt)
                        f.write(json.dumps(rec,ensure_ascii=False)+'\n'); f.flush(); attempt_counts[slot]=attempt+1
                        if rec['status']=='COMPLETED': completed+=1; completed_slots.add(slot)
                        else: failed+=1
        return {'scheduled':len(tids)*len(arm_ids)*repeats,'completed':completed,'failed':failed,'skipped':skipped,'arms':arm_ids,'tasks':tids,'config_hash':self.config_hash,'study_definition_hash':self.study_hash}


def make_backend(config, mock=False):
    return MockBackend() if mock else OpenAICompatibleBackend(config['backend'])
