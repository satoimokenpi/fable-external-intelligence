from __future__ import annotations
import argparse, json, sys, unittest
from .analyze import analyze, freeze_policy
from .backend import OpenAICompatibleBackend
from .evaluation import run_local_llm_judge, import_external_eval
from .runner import TrialRunner, make_backend
from .task_loader import package_root
from .utils import load_json


def cmd_self_test(args):
    suite=unittest.defaultTestLoader.discover(str(package_root()/'MOCK_TESTS'),pattern='test_*.py')
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    return 0 if result.wasSuccessful() else 1


def cmd_probe(args):
    cfg=load_json(args.config)
    try:
        out=OpenAICompatibleBackend(cfg['backend']).probe(); print(json.dumps(out,indent=2,ensure_ascii=False)); return 0
    except Exception as e:
        print('PROBE_FAILED:',e,file=sys.stderr); return 2


def cmd_run(args):
    cfg_path=args.transfer_config if args.transfer_config else args.config
    if args.transfer_config and args.experiment!='E8_TRANSFER':
        raise SystemExit('--transfer-config is allowed only for E8_TRANSFER')
    cfg=load_json(cfg_path)
    backend=make_backend(cfg,mock=args.mock)
    runner=TrialRunner(cfg,backend,args.run_id)
    out=runner.run_experiment(args.experiment,args.split,args.repeats)
    print(json.dumps(out,indent=2)); return 0


def cmd_analyze(args):
    print(json.dumps(analyze(args.run_id),indent=2)); return 0


def cmd_freeze(args):
    print(json.dumps(freeze_policy(args.run_id,args.config,allow_mock=args.allow_mock),indent=2)); return 0


def cmd_judge(args):
    print(json.dumps(run_local_llm_judge(args.run_id,args.judge_config,args.repeats),indent=2)); return 0


def cmd_import_eval(args):
    print(json.dumps(import_external_eval(args.run_id,args.file,args.source),indent=2)); return 0


def main(argv=None):
    p=argparse.ArgumentParser(description='Local-model A/B validation harness; no weight changes. External evaluators are optional and isolated from generation.')
    sp=p.add_subparsers(dest='cmd',required=True)
    s=sp.add_parser('self-test'); s.set_defaults(fn=cmd_self_test)
    s=sp.add_parser('probe'); s.add_argument('--config',required=True); s.set_defaults(fn=cmd_probe)
    s=sp.add_parser('run'); s.add_argument('--config',required=True); s.add_argument('--transfer-config',default=None,help='Second local target config; E8_TRANSFER only. Frozen policy remains from the original run-id.')
    s.add_argument('--run-id',required=True); s.add_argument('--experiment',required=True,choices=['E0_MEASUREMENT_NOISE','E1_QUALITY_REFERENCE','E2_COMPUTE_CONTROL','E3_VERIFICATION_TRUST','E4_PLANNING_AND_SCAFFOLD_GATE','E5_BRANCH_AND_ADVISOR','E6_LONG_LOOP_COMPLETION','E7_CORE_SIMPLIFICATION','E8_TRANSFER']); s.add_argument('--split',choices=['dev','holdout'],default='dev'); s.add_argument('--repeats',type=int,default=None); s.add_argument('--mock',action='store_true'); s.set_defaults(fn=cmd_run)
    s=sp.add_parser('analyze'); s.add_argument('--run-id',required=True); s.set_defaults(fn=cmd_analyze)
    s=sp.add_parser('freeze-policy'); s.add_argument('--config',required=True); s.add_argument('--run-id',required=True); s.add_argument('--allow-mock',action='store_true',help='Self-test only. Never use mock freeze for empirical claims.'); s.set_defaults(fn=cmd_freeze)
    s=sp.add_parser('judge-results'); s.add_argument('--run-id',required=True); s.add_argument('--judge-config',required=True); s.add_argument('--repeats',type=int,default=None); s.set_defaults(fn=cmd_judge)
    s=sp.add_parser('import-eval'); s.add_argument('--run-id',required=True); s.add_argument('--file',required=True); s.add_argument('--source',required=True,help='Evaluator source name, e.g. human, jev, langsmith'); s.set_defaults(fn=cmd_import_eval)
    a=p.parse_args(argv); return a.fn(a)


if __name__=='__main__': raise SystemExit(main())
