from __future__ import annotations
import hashlib, json, os, tempfile, time
from pathlib import Path

def load_json(path):
    return json.loads(Path(path).read_text(encoding='utf-8'))

def dump_json(path, obj):
    p=Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    tmp=p.with_suffix(p.suffix+'.tmp')
    tmp.write_text(json.dumps(obj, indent=2, ensure_ascii=False)+"\n", encoding='utf-8')
    os.replace(tmp,p)

def canonical_hash(obj):
    raw=json.dumps(obj, sort_keys=True, separators=(',',':'), ensure_ascii=False).encode('utf-8')
    return hashlib.sha256(raw).hexdigest()

def file_sha256(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for chunk in iter(lambda:f.read(1024*1024), b''): h.update(chunk)
    return h.hexdigest()

def now_utc():
    return time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

def estimate_tokens(text):
    # Diagnostic fallback only; never presented as tokenizer-exact.
    return max(1, (len(text)+3)//4)
