from __future__ import annotations
import re

def monitor(task, config):
    mode=config.get('experiment',{}).get('feature_mode','heuristic')
    ann=dict(task.get('observables') or {})
    if mode=='annotated': return ann
    prompt=task.get('prompt','')
    ev=len(task.get('evidence') or [])
    constraints=max(1, prompt.count(';')+prompt.count(' must ')+prompt.count(' keys ')+prompt.count('Return '))
    dep=1 + len(re.findall(r'\b(stage|then|after|depends|chain|A=|B=|C=)\b',prompt,re.I))
    sep=min(1.0, .2*len(task.get('subtasks') or []) + (.4 if ev>=3 else 0.0))
    amb=.75 if re.search(r'multiple|choose|tradeoff|plausible|recommend',prompt,re.I) else .15
    ver=1.0 if task.get('online_validator') else .25
    fresh=1.0 if re.search(r'current|today|latest|recent',prompt,re.I) else 0.0
    return {'constraint_count':constraints,'dependency_depth':dep,'separability':sep,'ambiguity':amb,'objective_verifiability':ver,'freshness_risk':fresh,'evidence_items':ev,'long_horizon':bool(task.get('obligations'))}

def gate(features, config):
    p=config.get('policy',{})
    simple=features.get('constraint_count',1)<p.get('high_constraint_count',4) and features.get('dependency_depth',1)<p.get('high_dependency_depth',3) and features.get('ambiguity',0)<p.get('high_ambiguity',.65) and features.get('separability',0)<p.get('high_separability',.65) and features.get('evidence_items',0)<3 and not features.get('long_horizon')
    dep=features.get('dependency_depth',1)>=p.get('high_dependency_depth',3)
    sep=features.get('separability',0)>=p.get('high_separability',.65)
    amb=features.get('ambiguity',0)>=p.get('high_ambiguity',.65)
    breadth=features.get('evidence_items',0)>=3 or sep or features.get('freshness_risk',0)>.5
    depth=dep or amb or features.get('constraint_count',1)>=p.get('high_constraint_count',4)
    return {
      'depth_high':bool(depth and not simple),'breadth_expand':bool(breadth and not simple),
      'decompose':bool(sep and not dep and not simple),'branch':bool(amb and not dep and not simple),
      'advisor':bool(amb and not simple),'verify':bool((not simple) and (features.get('objective_verifiability',0)>=.5 or depth or amb)),
      'long_loop':bool(features.get('long_horizon'))
    }

def trigger_metrics(task, actions):
    expected=task.get('expected_triggers') or {}; keys=sorted(set(expected)|set(actions))
    tp=fp=fn=tn=0
    per={}
    for k in keys:
        e=bool(expected.get(k,False)); a=bool(actions.get(k,False)); per[k]={'expected':e,'actual':a}
        if e and a:tp+=1
        elif not e and a:fp+=1
        elif e and not a:fn+=1
        else:tn+=1
    precision=tp/(tp+fp) if tp+fp else 1.0
    recall=tp/(tp+fn) if tp+fn else 1.0
    return {'trigger_precision':precision,'trigger_recall':recall,'tp':tp,'fp':fp,'fn':fn,'tn':tn,'per_trigger':per}

def system_prompt(depth=False):
    if depth:
        return 'Solve carefully. Before finalizing, check the explicit constraints and the highest-risk inference. Output only what the user requested; do not expose hidden chain-of-thought.'
    return 'Answer the task directly and follow the requested output format. Do not expose hidden chain-of-thought.'
