# FABLE / LINKs External Intelligence Harness — Alpha R2

A local-first A/B benchmark harness for testing whether **external inference control** can improve a local LLM without retraining or modifying its weights.

The harness compares a bare local model against optional external reasoning controllers such as adaptive compute, decomposition/planning, verification, branching/advisor selection, and long-loop completion.

> **Status:** TESTER-READY ALPHA R2. The harness mechanics are tested, but real-model capability gains are not yet established. This repository is for measurement, not a claim of Fable-equivalent performance.

## What R2 fixes

R2 closes benchmark-integrity issues found in review, including:

- complete accounting for judge/selector model calls and resource usage
- failed API calls recorded as FAILED trials instead of aborting the study
- strict dev-completion and config/study integrity checks before policy freeze
- post-freeze tamper/config-change detection
- E8 transfer requiring genuinely distinct targets before `KEEP`
- `json_subset` scoring that enforces all required obligations
- deterministic per-repeat task variation to reduce fixed-answer overfitting
- optional blind local LLM-as-a-Judge and post-hoc external evaluator import

See `15_R2_FIX_CHANGELOG.md` for details.

## Requirements

- Python 3.10+
- A local LLM served through an OpenAI-compatible endpoint
- LM Studio is the reference runtime
- Default endpoint: `http://127.0.0.1:1234/v1`
- No additional pip package is normally required

## Quick start

```powershell
python -m HARNESS.cli self-test
Copy-Item .\02_RUNTIME_CONFIG_TEMPLATE.json .\runtime.local.json
# Edit runtime.local.json for your actual local model/runtime
python -m HARNESS.cli probe --config .\runtime.local.json
```

Then follow `11_RUN_LOCAL_INSTRUCTIONS.md` for the required dev → freeze → holdout → transfer sequence.

## Validation status

The packaged R2 release reports:

- Python compile: PASS
- machine-readable JSON/YAML parse: PASS
- unit/mock self-test: **19/19 PASS**
- synthetic end-to-end integration: **1,795 completed trial records / 0 failures**

Real-model quality improvement, cross-model reproducibility, quantization effects, and LINKs production integration remain to be measured.

## Important files

- `00_START_HERE_JP.md` — Japanese quick start and project scope
- `01_ALPHA_STATUS.md` — validated vs. unvalidated claims
- `11_RUN_LOCAL_INSTRUCTIONS.md` — exact benchmark execution order
- `14_EVALUATOR_GUIDE.md` — optional judge/external evaluator workflow
- `15_R2_FIX_CHANGELOG.md` — R2 integrity fixes
- `HARNESS/` — benchmark implementation
- `TASKS/` — dev and holdout tasks

## Scope / disclaimer

This project does **not** modify model weights or architecture. It does not claim to reproduce a vendor's private implementation. It clean-room reconstructs externally realizable reasoning/control patterns from public or observable behavior and measures their effect on local models.

This project is not affiliated with or endorsed by Anthropic, OpenAI, Moonshot AI, LM Studio, or other referenced vendors.

## License

No open-source license has been selected yet. Unless a license is added, normal copyright restrictions apply.
