# Scoring and Ground Truth — R2

## 分離ルール

各タスクには公開フィールドとprivate evaluationフィールドがあります。モデル生成へ入るのは `HARNESS.task_loader.generation_messages()` が組み立てた `prompt / evidence / public_rubric` だけです。`private_evaluation`、`mock`、`expected_triggers`、`online_validator`、`variant_generator` はモデルへ渡しません。

**Holdout answerはgeneration promptへ挿入しません。** Mock fixtureは自己テスト専用で、実モデル性能の根拠にはしません。

## 2種類の検証

1. **Online validator** — calculator/unit test/schema validatorのように、戦略側が利用可能な決定論的チェック。
2. **Offline ground truth** — 実験後の採点専用。branch選択、repair、stop判断には使いません。

Verifier自身のPASSはground truthではありません。R2ではverifier PASSとoffline objective scoreを後から比較し、false-passを記録します。

## `json_subset` 修正

R2では `json_subset` のexpected fieldsだけが正しくても、宣言された必須obligationsが欠けていれば成功にしません。

- `content_score`: expected内容の正しさ
- `completion_score`: 必須obligationsの充足率
- final `score = min(content_score, completion_score)`
- `passed=true` は両方が100%の時だけ

## 固定解依存の緩和

13の客観タスクに決定論的variant generatorを追加しました。

- 同じ `task + repeat` は全armで同じ問題 → paired A/B公平性を維持
- repeatが変わると具体的な数値/並び/正解が変わる → 定数暗記への依存を低減
- variant generator定義と正解はモデルpromptへ渡さない

## Optional post-hoc evaluator

客観タスクは決定論的ground truthを最優先します。Open-ended/rubric-proxyタスクには必要に応じて、

- blind local LLM-as-a-judge
- Jev等の外部評価器
- human labels
- LangSmith等

を**生成後**に追加できます。これらのscoreは `posthoc_evaluator_score` として別扱いで、objective ground truthを上書きしません。詳細は `14_EVALUATOR_GUIDE.md`。

## Persisted result integrity

Freeze/holdout前に、completed trialは以下を再検証します。

- trial slot / attempt key
- task variantからoffline scoreを再計算
- `results.jsonl` とraw JSONの一致
- raw call-record件数とinference call countの一致
- success/failure call count
- reported token totals
- estimated input totals
- attempted output token cap

これにより、採点値やcall countだけが壊れた状態でholdoutへ進むことを防ぎます。
