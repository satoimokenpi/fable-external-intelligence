# FABLE / LINKs External Intelligence Harness — Alpha R2

ローカルLLMに「計画・分解・自己検証・複数案比較・必要時だけ追加推論する」といった外付け推論制御を加え、**素のモデルより本当に良くなるか**をA/B検証するテスト版です。

R2では、外部レビューで見つかったベンチマーク上の問題を修正しました。特に、judge/selectorの呼び出し漏れ、freeze後の設定変更、E8一対象での過大判定、API失敗の消失、必須項目欠落の見逃しを塞いでいます。詳細は `15_R2_FIX_CHANGELOG.md` を参照してください。

## いま何ができるか

- LM StudioなどのOpenAI互換**ローカル**APIに接続
- 素の推論と外付け知能を同一条件で比較
- Adaptive Compute / Verification / Planning / Branching / Advisor / Long-loop を個別に検証
- dev → policy freeze → holdout を強制し、freeze後の改変を検出
- API失敗もFAILED試行として保存し、品質と信頼性/資源を分離集計
- 固定解だけに依存しないよう、一部客観タスクをrepeatごとに決定論的に変形
- rubric/open-endedタスクへ任意でblind local LLM judgeを追加
- Jev等・human・別評価器の結果を後付けJSONLで取り込み
- 2つ目のローカルモデル/量子化/runtimeへの転用性をE8で検証

## 重要

これは **Alpha R2 / 実験版** です。

ハーネスの制御・整合性は自己テストと合成統合試験を通過していますが、配布時点では「どのローカルLLMでも確実に賢くなる」とは証明していません。そこを実モデルで検証するためのパッケージです。

モデルのweights、architecture、quantizationは変更しません。Fableそのものを複製するものでもありません。公開・観測可能な挙動から外部化可能な推論パターンをclean-room的に再構成し、ローカルLLMへ後付けした時の効果を測ります。

## 必要なもの

- Python 3.10以上
- LM Studio等でロード済みのローカルLLM
- OpenAI互換ローカルAPI
- 既定値: `http://127.0.0.1:1234/v1`

追加pipパッケージは原則不要です。

## 最短手順

1. ZIPを展開
2. LM Studioでモデルをロードし、Local Serverを起動
3. PowerShell/Terminalで展開フォルダを開く
4. 自己テスト

```powershell
python -m HARNESS.cli self-test
```

5. `02_RUNTIME_CONFIG_TEMPLATE.json` を `runtime.local.json` にコピー
6. `backend.model` と `model_metadata` を実環境に合わせる
7. 接続確認

```powershell
python -m HARNESS.cli probe --config .\runtime.local.json
```

8. `11_RUN_LOCAL_INSTRUCTIONS.md` の順番で実験

実験後は `RUNS/<run-id>/analysis.md` と `analysis.json` を返してもらうと比較しやすいです。
