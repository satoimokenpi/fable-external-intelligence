# Codex publish notes

This folder is prepared for publication to:

`https://github.com/satoimokenpi/1.0.git`

Before push, run `python -m HARNESS.cli self-test` and verify 19/19 PASS.
Do not commit `runtime.local.json`, `runtime.transfer.json`, `judge.local.json`, `RUNS/`, `.env*`, or caches.
Do not force-push over pre-existing unrelated remote history.
