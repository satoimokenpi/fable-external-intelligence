# Run Locally — Alpha R2

Python 3.10+ と、OpenAI互換ローカルendpointで既にロード済みのmodelが必要です。LM Studio local serverをreferenceにしています。

## 1. Extract and enter the package

```powershell
Expand-Archive .\FABLE_LINKS_EXTERNAL_INTELLIGENCE_ALPHA_R2_20260925.zip -DestinationPath .\FABLE_LINKS_EXTERNAL_INTELLIGENCE_ALPHA_R2_20260925
cd .\FABLE_LINKS_EXTERNAL_INTELLIGENCE_ALPHA_R2_20260925
```

## 2. Self-test

```powershell
python -m HARNESS.cli self-test
```

19 testsがPASSすることを確認してください。

## 3. Create runtime config

```powershell
Copy-Item .\02_RUNTIME_CONFIG_TEMPLATE.json .\runtime.local.json
```

`runtime.local.json` で最低限、

- `backend.model`
- `model_metadata.model_id`
- `model_metadata.quantization`
- `model_metadata.runtime`
- hardware/cache/warm-state notes

を実環境に合わせてください。API keyは使いません。既定endpointは `http://127.0.0.1:1234/v1` です。public Internet/provider hostは拒否されます。

## 4. Probe

```powershell
python -m HARNESS.cli probe --config .\runtime.local.json
```

## 5. Dev — required order

```powershell
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E0_MEASUREMENT_NOISE --split dev
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E1_QUALITY_REFERENCE --split dev
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E2_COMPUTE_CONTROL --split dev
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E3_VERIFICATION_TRUST --split dev
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E4_PLANNING_AND_SCAFFOLD_GATE --split dev
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E5_BRANCH_AND_ADVISOR --split dev
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E6_LONG_LOOP_COMPLETION --split dev
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E7_CORE_SIMPLIFICATION --split dev
python -m HARNESS.cli analyze --run-id localA
python -m HARNESS.cli freeze-policy --config .\runtime.local.json --run-id localA
```

R2ではrequired dev matrixが完全でない、FAILED slotが未解決、configが混在、study code/taskが変わった、score/raw accountingが不整合、という場合はfreezeを拒否します。

## 6. Holdout after freeze

```powershell
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E1_QUALITY_REFERENCE --split holdout
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E2_COMPUTE_CONTROL --split holdout
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E3_VERIFICATION_TRUST --split holdout
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E4_PLANNING_AND_SCAFFOLD_GATE --split holdout
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E5_BRANCH_AND_ADVISOR --split holdout
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E6_LONG_LOOP_COMPLETION --split holdout
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E7_CORE_SIMPLIFICATION --split holdout
python -m HARNESS.cli analyze --run-id localA
```

## 7. E8 transfer

`analysis.json` の `e7_winner` が `A0_*` なら、外付けpolicyはdevでcontrolに負けています。R2はE8を拒否します。

外付けpolicyが生き残った場合だけ、まず元target:

```powershell
python -m HARNESS.cli run --config .\runtime.local.json --run-id localA --experiment E8_TRANSFER --split holdout
```

次に2つ目の**実際に異なる**local target:

```powershell
Copy-Item .\runtime.local.json .\runtime.transfer.json
# model / quantization / runtime等を実targetに合わせて変更。policy/samplingは変えない。
python -m HARNESS.cli run --config .\runtime.local.json --transfer-config .\runtime.transfer.json --run-id localA --experiment E8_TRANSFER --split holdout
python -m HARNESS.cli analyze --run-id localA
```

`transfer.target_tag` は表示用metadataであり、それだけ変更してもdistinct targetにはなりません。

## 8. Optional blind evaluator

Open-ended/rubric taskを補助評価する場合:

```powershell
Copy-Item .\12_JUDGE_CONFIG_TEMPLATE.json .\judge.local.json
# local judge modelを設定
python -m HARNESS.cli judge-results --run-id localA --judge-config .\judge.local.json
python -m HARNESS.cli analyze --run-id localA
```

Jev/human/他評価器は `13_EXTERNAL_EVAL_SCHEMA.json` のJSONLへしてimport:

```powershell
python -m HARNESS.cli import-eval --run-id localA --file .\external_eval.jsonl --source jev
python -m HARNESS.cli analyze --run-id localA
```

## Resume / failure

- COMPLETED slotは再実行時にskip。
- FAILED slotは保存され、次の同commandで `attempt=N+1` として再試行。
- judge/selectorを含む全model call attemptがresource accountingへ入ります。
- provider/local API failure時の実課金有無が不明な場合は `billed_usage_unknown=true` として記録します。

## Outputs

`RUNS/<run-id>/`

- `results.jsonl` — trial attempts
- `raw/*.json` — raw call records
- `analysis.json` / `analysis.md`
- `POLICY_SNAPSHOT.json` — freeze後
- `judge_results.jsonl` — optional local judge
- `external_evaluations.jsonl` — optional imported evaluator
